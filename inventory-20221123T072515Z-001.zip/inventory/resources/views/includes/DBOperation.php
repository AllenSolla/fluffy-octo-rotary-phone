<?php
class DBOperation
{
    private $con;

    public function connect(){
        include_once("/config/database.php");
    $this->con= new Mysqli(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
    return $this->con;
    }
public function getAllRecords($table){
    $pre_smt = $this->con->prepare("SELECT * FROM".$table);
    $pre_smt->execute() or die($this->con->error);
    $result = $pre_smt->get_result();
    $rows = array();
    if ($result->num_rows > 0){
        while ($row = $result->fetch_assoc()){
            $rows[] = $row;    
        }
        return $rows;
    }
    return "NO_DATA";
}}
