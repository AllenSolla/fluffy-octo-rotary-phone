<?php
if (isset($_POST["getNewOrderItem"])){
    $obj = new InvoiceController();
    $row = $obj->getAllRecords("products"); 
    ?>
    <tr>
    <td id="number">1</td>
    <td>
    <select id="prod_id[]" class="form-control form-control-sm">
    <?php
    foreach($rows as $row){
        ?> <option value="<?php echo $row['prod_id'];?>"><?php echo $row['prod_name'];?></option> 
    <?php
    }
    ?>
    <option>--Select product--</option>
    </select>
    </td>
    <td> <input name="tqty" id="tqty[]" type="text" class="form-control form-control-sm"  readonly> </td>
    <td> <input name="qty" id="qty[]" type="text" class="form-control form-control-sm" >  </td>
    <td>  <input name="price" id="price[]" type="text" class="form-control form-control-sm"readonly>  </td>
    <td>P<span> 2000</span></td>
    </tr>
    <?php
    exit(); 
}
?>