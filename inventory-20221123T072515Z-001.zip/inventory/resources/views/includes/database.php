<?php
define ("HOST","127.0.0.1");
define ("USER","allen");
define ("PASS","<Soll@0900>");
define ("DB","clickventory");
