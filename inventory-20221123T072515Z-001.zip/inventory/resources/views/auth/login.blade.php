@extends('layouts.layout')
@section('content')
<br> 
<div class="card mx-auto" style="width: 30rem;">
<p></p>
<img src="img/login.jpg" class="mx-auto" style="width:90%;" alt="Login icon">
  <div class="card-body">
    <h5 class="card-title"></h5>
    <form action="{{route('login')}}" method="post">
    @csrf
  <div class="mb-3">
  <label for="email" class="form-label">{{ __('E-Mail Address') }}</label>
    @if (session('status'))
    <label for="email" class="col-md-2 col-form-label text-md-right">
   {{session('status')}}
   @endif</label>
  <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}">
    @error('email')
    <span class="invalid-feedback" role="alert">
    <strong>{{ $message }}</strong>
    </span>
    @enderror
    
   
  <div class="mb-3">
  <label for="password" class="form-label">{{ __('Password') }}</label>
  <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password">
    @error('password')
    <span class="invalid-feedback" role="alert">
    <strong>{{ $message }}</strong>
    </span>
    @enderror  
    </div>
        
  <div class="mb-3 form-check">
  <input type="checkbox" name="remember" id="remember" class="mr-3">
    <label for="remember">Remember</label>
  </div>
    <button type="submit" class="btn btn-primary"> <i class="fa fa-lock">&nbsp;</i>
    {{ __('Login') }}
    </button>
    &nbsp;<span> <a href="{{route('register')}}">Register</a> </span>
</form>    

</div>
<div class="card-footer">
<a href="#">Forget Password?</a>
</div>
</div></div>
@endsection
</body>
</html
