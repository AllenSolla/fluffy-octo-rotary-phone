@extends('layouts.layout')
@section('content')

<br> 
<div class="card mx-auto" style="width: 30rem;">
<img src="img/login.jpg" class="mx-auto" style="width:90%;" alt="Login icon">
  <div class="card-body">
    <h5 class="card-title"></h5>
    <form action="{{route('register')}}" method="post">
    @csrf
    <div class="mb-3">
    <label for="first_name" class="form-label">{{ __('First Name') }}</label>
    <input id="first_name" type="text" class="form-control @error('first_name') is-invalid @enderror" name="first_name" value="{{ old('first_name') }}">
         @error('first_name')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
        
        <div class="mb-3">
        <label for="last_name" class="form-label">{{ __('Last Name') }}</label>
        <input id="last_name" type="text" class="form-control @error('last_name') is-invalid @enderror" name="last_name" value="{{ old('last_name') }}">
         @error('last_name')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror

        <div class="mb-3">
        <label for="Address" class="form-label">{{ __('Address') }}</label>
        <input id="Address" type="text" class="form-control @error('Address') is-invalid @enderror" name="Address" value="{{ old('Address') }}">
        @error('Address')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror

        <div class="mb-3">
        <label for="user_type" class="form-label">{{ __('User type') }}</label>
        <input id="user_type" type="text" class="form-control @error('user_type') is-invalid @enderror" name="user_type" value="{{ old('user_type') }}">
        @error('user_type')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror

        <div class="mb-3">
        <label for="Contact" class="form-label">{{ __('Mobile Number') }}</label>
        <input id="Contact" type="text" class="form-control @error('Contact') is-invalid @enderror" name="Contact" value="{{ old('Contact') }}">
        @error('Contact') 
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror

  <div class="mb-3">
  <label for="email" class="form-label">{{ __('E-Mail Address') }}</label>
    @if (session('status'))
    <label for="email" class="col-md-2 col-form-label text-md-right">
   {{session('status')}}
   @endif</label>
  <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}">
    @error('email')
    <span class="invalid-feedback" role="alert">
    <strong>{{ $message }}</strong>
    </span>
    @enderror
    
   
  <div class="mb-3">
  <label for="password" class="form-label">{{ __('Password') }}</label>
  <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password">
    @error('password')
    <span class="invalid-feedback" role="alert">
    <strong>{{ $message }}</strong>
    </span>
    @enderror  
    </div>
  
    <div class="mb-3">
    <label for="password-confirm" class="form-label">{{ __('Confirm Password') }}</label>
    <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
    @error('password')
    <span class="invalid-feedback" role="alert">
    <strong>{{ $message }}</strong>
    </span>
    @enderror  
    </div>
    <button type="submit" class="btn btn-primary"> <i class="fa fa-lock">&nbsp;</i>
    {{ __('Register') }}
    </button>
    &nbsp;<span> <a href="{{route('login')}}">Login</a> </span>
</form>    
</div>
</div></div>
</div>
</div>
 
@endsection