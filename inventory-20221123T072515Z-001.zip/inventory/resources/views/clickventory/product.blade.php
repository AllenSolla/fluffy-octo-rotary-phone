@extends('layouts.layout')
@section('content')
<p></p>
<div class="container">
<table class="table table-hover table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Stock</th>
        <th>Product Image</th>
        <th>Product Category</th>
        <th>Product Brand</th>
        <th>Product Expiration</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    @foreach($product as $products)
      <tr>
      
        <td value="{{ $products->prod_id}}"> {{ $products->prod_id }} </td>
        <td value="{{ $products->prod_name}}"> {{ $products->prod_name }} </td>
        <td value="{{ $products->prod_price}}"> {{ $products->prod_price }} </td>
        <td value="{{ $products->prod_quan}}"> {{ $products->prod_quan }} </td>
        <td value="{{ $products->prod_image}}"> {{ $products->prod_image }} </td>
        <td value="{{ $products->cat_id}}"> {{ $products->cat_id }} </td>
        <td value="{{ $products->brand_id}}"> {{ $products->brand_id }} </td>
        <td value="{{ $products->prod_exp}}"> {{ $products->prod_exp }} </td>
        <td>
        <a href="/product/{{ $products->prod_id }}" class="btn btn-success btn-sm"> <li class="fa fa-edit">&nbsp;</li> Update</a>
        <p></p>
        <form action="/product/{{ $products->prod_id }}" method="post">
        @csrf  @method('DELETE')
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash">&nbsp;</i>Delete</button>
        </form> </td>
      </tr>
      @endforeach
    </tbody>
  </table>
  </div>
@endsection