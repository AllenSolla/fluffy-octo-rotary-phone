@extends('layouts.layout')
@section('content')
<div class="container">
<form  action="/brand/{{ $brand->brand_id }}" method="POST">       
@csrf
@method('PUT')     
<table class="table table-hover table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Brand Name</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <td value="{{ $brand->brand_id }}">{{$brand->brand_id}}      
      </td>

        <td>   
        <input type="edit_brand" class="form-control" name="edit_brand" id="edit_brand" value="{{ $brand->brand}}"></td>
        <td>
        <button type="submit" class="btn btn-primary"><i class="fa fa-pencil">&nbsp;</i>Update</button> </td>      
      </tr>
 
@endsection



