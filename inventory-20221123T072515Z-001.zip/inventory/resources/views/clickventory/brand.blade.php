@extends('layouts.layout')
@section('content')
<p></p>
<a href="#" data-toggle="modal" data-target="#brand" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
<!--Category Modal -->
<div class="modal fade" id="brand" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="category">Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
      <form action="/brand" method="post">
      @csrf
    <div class="form-group">
    <label for="brand" class="form-label">{{ __('Brand Name') }}</label>
    <input id="brand" type="text" class="form-control @error('brand') is-invalid @enderror" name="brand" value="{{ old('brand') }}">
         @error('brand')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>
  <button type="submit" class="btn btn-primary">Add Brand</button>
</form>
  </div>  
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>
<!-- add modal end-->

<div class="container">
<table class="table table-hover table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Brand</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    @foreach($brand as $brands)
      <tr>
      <td value="{{ $brands->brand_id }}" > {{ $brands->brand_id }} </td>
        <td value="{{ $brands->brand }}" > {{ $brands->brand }} </td>
        <td>
        <a href="/brand/{{$brands->brand_id}}" class="btn btn-primary"><i class="fa fa-edit">&nbsp;</i>Edit</a>
        <p></p>
        <form action="/brand/{{ $brands->brand_id }}" method="post">
        @csrf  @method('DELETE')
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash">&nbsp;</i>Delete</button>
        </form> 

        </td>        
      </tr>
      @endforeach
      
    </tbody>
  </table>
  </div>
@endsection
