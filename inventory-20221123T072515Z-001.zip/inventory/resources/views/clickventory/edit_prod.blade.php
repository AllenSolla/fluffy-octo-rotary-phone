@extends('layouts.layout')
@section('content')
<div class="container">
<form  action="/product/{{ $product->prod_id }}" method="POST">       
@csrf
@method('PUT')     
<table class="table table-hover table-bordered">
    <thead>
      <tr>
      <th>#</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Stock</th>
        <th>Product Image</th>
        <th>Product Expiration</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <td value="{{ $product->prod_id }}">{{$product->prod_id}}      
      </td>

        <td>   
        <input id="product" type="text" class="form-control" name="product" value="{{ $product->prod_name }}">
        </td>
        <td>
        <input id="product_price" type="text" class="form-control" name="product_price" value="{{ $product->prod_price }}">
        </td>
        <td>
        <input id="product_quan" type="text" class="form-control" name="product_quan" value="{{ $product->prod_quan }}">
        </td>
        <td>
        <input id="product_image" type="file" class="form-control" name="product_image" value="{{ $product->prod_image }}">
        <td>
        <input id="product_exp" type="text" class="form-control" name="product_exp" value="{{ $product->prod_exp }}">
        </td>
        <td>
        <button type="submit" class="btn btn-primary"><i class="fa fa-pencil">&nbsp;</i>Update</button> </td>      
      </tr>
 
@endsection



