<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\InvoiceController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/home', function () { 
return view('home'); 
})->name('home');
Route::resource('/category', CategoryController::class);
Route::resource('/brand', BrandController::class);
Route::resource('/order', InvoiceController::class);
Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::GET('/login', [LoginController::class, 'index'])->name('login');
Route::get('/logout', [LogoutController::class, 'store'])->name('logout');
Route::post('/login', [LoginController::class, 'store']);
Route::GET('/register', [RegisterController::class, 'index'])->name('register');
Route::resource('/product', ProductController::class);
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/', function () {
    return view('welcome');
});


