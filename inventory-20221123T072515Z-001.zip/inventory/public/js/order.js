$ (document).ready(function(){   
    var DOMAIN ="http://127.0.0.1:8000/order";
    
    addNewRow();
    
    $("#add").click(function(){
        addNewRow();
    })

    function addNewRow(){
        $.ajax({
            url : "Includes/process.php",
            method : "POST",
            data : {getNewOrderItem:1},
            success : function(data){
              $("tbody").append(data);
            } 
        })

    }

});