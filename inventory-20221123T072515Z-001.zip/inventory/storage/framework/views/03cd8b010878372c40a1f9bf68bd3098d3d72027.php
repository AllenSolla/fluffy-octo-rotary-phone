<?php $__env->startSection('content'); ?>
<div class="container">
<form  action="/product/<?php echo e($product->prod_id); ?>" method="POST">       
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>     
<table class="table table-hover table-bordered">
    <thead>
      <tr>
      <th>#</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Stock</th>
        <th>Product Image</th>
        <th>Product Expiration</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <td value="<?php echo e($product->prod_id); ?>"><?php echo e($product->prod_id); ?>      
      </td>

        <td>   
        <input id="product" type="text" class="form-control" name="product" value="<?php echo e($product->prod_name); ?>">
        </td>
        <td>
        <input id="product_price" type="text" class="form-control" name="product_price" value="<?php echo e($product->prod_price); ?>">
        </td>
        <td>
        <input id="product_quan" type="text" class="form-control" name="product_quan" value="<?php echo e($product->prod_quan); ?>">
        </td>
        <td>
        <input id="product_image" type="file" class="form-control" name="product_image" value="<?php echo e($product->prod_image); ?>">
        <td>
        <input id="product_exp" type="text" class="form-control" name="product_exp" value="<?php echo e($product->prod_exp); ?>">
        </td>
        <td>
        <button type="submit" class="btn btn-primary"><i class="fa fa-pencil">&nbsp;</i>Update</button> </td>      
      </tr>
 
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/clickventory/edit_prod.blade.php ENDPATH**/ ?>