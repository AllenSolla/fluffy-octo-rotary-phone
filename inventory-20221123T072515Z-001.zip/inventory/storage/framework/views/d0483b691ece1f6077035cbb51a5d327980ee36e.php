<?php $__env->startSection('content'); ?>
<br>
<div class="container">
    <div class="row">   
        <div class="col-md-4">
        <div class="card mx-auto" style="width: 20rem;">
        <img class="card-img-top mx-auto" src="img/Dashboard.gif"  style="width:100%;" alt="Login icon">
        <div class="card-body"> 
        <h5 class="card-title">Profile Info</h5>
        <p class="card-text"><i class="fa fa-user">&nbsp;</i><?php echo e(auth()->user()->first_name); ?></p>
        <p class="card-text"><i class="fa fa-user">&nbsp;</i><?php echo e(auth()->user()->u_type); ?></p>
        <p class="card-text">Last Login : xxxx-xx-xx</p>
        <a href="#" class="btn btn-primary"> <i class="fa fa-edit">&nbsp;</i> Edit Profile</a>
</div>
</div>
</div>
<div class="col-md-8">
    <div class="jumbotron" style="width:100%;height:100%;">
    <h1>WELCOME</h1>
    <div class="row">
    <div class="col-sm-6">
    <iframe src="http://free.timeanddate.com/clock/i7m5eiuz/n145/szw110/szh110/cf100/hnce1ead6" frameborder="0" width="110" height="110"></iframe>
    </div>
    
    <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">New Orders</h5>
        <p class="card-text">Here you can make new Orders and Invoice.</p>
        <a href="#" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>New Orders</a>
      </div>
    </div>
    </div>
    </div>
</div>
</div>
</div>
</div>
<p></p>
<p></p>
<div class="container">
<div class="row">
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Categories</h5>
        <p class="card-text">Here you can add and manage categories.</p>
        <a href="#" data-toggle="modal" data-target="#category" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
        <a href="#" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Brands</h5>
        <p class="card-text">Here you can add and manage brands.</p>
        <a href="#" data-toggle="modal" data-target="#brands" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
        <a href="#" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Products</h5>
        <p class="card-text">Here you can add and manage products.</p>
        <a href="#" data-toggle="modal" data-target="#product" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i> Add</a>
        <a href="#" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
</div>
</div>
<?php
include_once("/home/allen/inventory/resources/views/auth/category.blade.php")
?>
<?php
include_once("/home/allen/inventory/resources/views/auth/brand.blade.php")
?>
<?php
include_once("/home/allen/inventory/resources/views/auth/product.blade.php")
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/post/dashboard.blade.php ENDPATH**/ ?>