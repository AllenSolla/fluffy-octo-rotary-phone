<?php $__env->startSection('content'); ?>
<br> 
<div class="card mx-auto" style="width: 30rem;">
<p></p>
<img src="img/login.jpg" class="mx-auto" style="width:90%;" alt="Login icon">
  <div class="card-body">
    <h5 class="card-title"></h5>
    <form action="<?php echo e(route('login')); ?>" method="post">
    <?php echo csrf_field(); ?>
  <div class="mb-3">
  <label for="email" class="form-label"><?php echo e(__('E-Mail Address')); ?></label>
    <?php if(session('status')): ?>
    <label for="email" class="col-md-2 col-form-label text-md-right">
   <?php echo e(session('status')); ?>

   <?php endif; ?></label>
  <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
   
  <div class="mb-3">
  <label for="password" class="form-label"><?php echo e(__('Password')); ?></label>
  <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password">
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
    </div>
        
  <div class="mb-3 form-check">
  <input type="checkbox" name="remember" id="remember" class="mr-3">
    <label for="remember">Remember</label>
  </div>
    <button type="submit" class="btn btn-primary"> <i class="fa fa-lock">&nbsp;</i>
    <?php echo e(__('Login')); ?>

    </button>
    &nbsp;<span> <a href="<?php echo e(route('register')); ?>">Register</a> </span>
</form>    

</div>
<div class="card-footer">
<a href="#">Forget Password?</a>
</div>
</div></div>
<?php $__env->stopSection(); ?>
</body>
</html

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/auth/login.blade.php ENDPATH**/ ?>