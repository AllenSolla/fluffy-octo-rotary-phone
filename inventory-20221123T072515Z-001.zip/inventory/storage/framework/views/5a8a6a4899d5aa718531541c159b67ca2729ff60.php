<label><?php echo e(__('Brand')); ?></label>
    <select name="product_brand" id="product_brand" required>
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select><?php /**PATH /home/allen/inventory/resources/views/clickventory/products.blade.php ENDPATH**/ ?>