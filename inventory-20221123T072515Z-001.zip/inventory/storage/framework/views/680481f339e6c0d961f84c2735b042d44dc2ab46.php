<?php $__env->startSection('content'); ?>
<p></p>
<div class="container">
<table class="table table-hover table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Stock</th>
        <th>Product Image</th>
        <th>Product Category</th>
        <th>Product Brand</th>
        <th>Product Expiration</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      
        <td value="<?php echo e($products->prod_id); ?>"> <?php echo e($products->prod_id); ?> </td>
        <td value="<?php echo e($products->prod_name); ?>"> <?php echo e($products->prod_name); ?> </td>
        <td value="<?php echo e($products->prod_price); ?>"> <?php echo e($products->prod_price); ?> </td>
        <td value="<?php echo e($products->prod_quan); ?>"> <?php echo e($products->prod_quan); ?> </td>
        <td value="<?php echo e($products->prod_image); ?>"> <?php echo e($products->prod_image); ?> </td>
        <td value="<?php echo e($products->cat_id); ?>"> <?php echo e($products->cat_id); ?> </td>
        <td value="<?php echo e($products->brand_id); ?>"> <?php echo e($products->brand_id); ?> </td>
        <td value="<?php echo e($products->prod_exp); ?>"> <?php echo e($products->prod_exp); ?> </td>
        <td>
        <a href="/product/<?php echo e($products->prod_id); ?>" class="btn btn-success btn-sm"> <li class="fa fa-edit">&nbsp;</li> Update</a>
        <p></p>
        <form action="/product/<?php echo e($products->prod_id); ?>" method="post">
        <?php echo csrf_field(); ?>  <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash">&nbsp;</i>Delete</button>
        </form> </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/clickventory/product.blade.php ENDPATH**/ ?>