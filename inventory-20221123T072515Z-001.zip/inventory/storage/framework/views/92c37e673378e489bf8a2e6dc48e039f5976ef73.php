<?php $__env->startSection('content'); ?>
<!-- Side Card -->
<br>
<div class="container">
    <div class="row">   
        <div class="col-md-4">
        <div class="card mx-auto" style="width: 20rem;">
        <img class="card-img-top mx-auto" src="img/Dashboard.gif"  style="width:100%;" alt="Login icon">
        <div class="card-body"> 
        <h5 class="card-title">Profile Info</h5>
        <p class="card-text"><i class="fa fa-user">&nbsp;</i><?php echo e(auth()->user()->first_name); ?></p>
        <p class="card-text"><i class="fa fa-user">&nbsp;</i><?php echo e(auth()->user()->u_type); ?></p>
        <p class="card-text">Last Login : xxxx-xx-xx</p>
        <a href="#" class="btn btn-primary"> <i class="fa fa-eye">&nbsp;</i> View Users</a>
        <a href="Edit_profile" class="btn btn-primary"> <i class="fa fa-edit">&nbsp;</i> Edit Profile</a>
</div>
</div>
</div>
<div class="col-md-8">
    <div class="jumbotron" style="width:100%;height:100%;">
    <h1>WELCOME</h1>
    <div class="row">
    <div class="col-sm-6">
    <iframe src="http://free.timeanddate.com/clock/i7m5eiuz/n145/szw110/szh110/cf100/hnce1ead6" frameborder="0" width="110" height="110"></iframe>
    </div>
    
    <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">New Orders</h5>
        <p class="card-text">Here you can make new Orders and Invoice.</p>
        <a href="order" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>New Orders</a>
      </div>
    </div>
    </div>
    </div>
</div>
</div>
</div>
</div>
<!-- Card -->
<p></p>
<p></p>
<div class="container">
<div class="row">
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Categories</h5>
        <p class="card-text">Here you can add and manage categories.</p>
        <a href="#" data-toggle="modal" data-target="#category" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
        <a href="/category" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Brands</h5>
        <p class="card-text">Here you can add and manage brands.</p>
        <a href="#" data-toggle="modal" data-target="#brand" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
        <a href="/brand" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Products</h5>
        <p class="card-text">Here you can add and manage products.</p>
        <a href="#" data-toggle="modal" data-target="#product" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i> Add</a>
        <a href="/product" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
</div>
</div>
<!--Category Modal -->
<div class="modal fade" id="category" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="category">Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
      <form action="/category" method="post">
      <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="category" class="form-label"><?php echo e(__('Category Name')); ?></label>
    <input id="category" type="text" class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="category" value="<?php echo e(old('category')); ?>">
         <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
  <div class="form-group">
  <label for="parent_cat" class="form-label"><?php echo e(__('Parent category')); ?></label>
    <input id="parent_cat" type="text" class="form-control <?php $__errorArgs = ['parent_cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="parent_cat" value="<?php echo e(old('parent_cat')); ?>">
         <?php $__errorArgs = ['parent_cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
  <button type="submit" class="btn btn-primary">Add Category</button>
</form>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>

<!--Brand Modal -->
<div class="modal fade" id="brand" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="brand">Brand</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<div class="modal-body">
      <form action="/brand" method="post">
      <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="brand" class="form-label"><?php echo e(__('Brand Name')); ?></label>
    <input id="brand" type="text" class="form-control <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="brand" value="<?php echo e(old('brand')); ?>">
         <?php $__errorArgs = ['Brand Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
  <button type="submit" class="btn btn-primary">Add Brand</button>
</form>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>

<!--Product Modal -->
<div class="modal fade" id="product" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="product">Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<div class="modal-body">
      <form action="/product" method="post">
      <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="product" class="form-label"><?php echo e(__('Product Name')); ?></label>
    <input id="product" type="text" class="form-control <?php $__errorArgs = ['prouct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="product" value="<?php echo e(old('product')); ?>">
         <?php $__errorArgs = ['Product Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-group">
    <label><?php echo e(__('Category')); ?></label>
    <select name="product_cat" id="product_cat" class="form-control">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($category->cat_id); ?>"><?php echo e($category->cat_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
       </div> 
       <label><?php echo e(__('Brand')); ?></label>
    <select name="product_brand" id="product_brand" class="form-control" >
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($brand->brand_id); ?>" ><?php echo e($brand->brand); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
       </div> 
        <div class="form-group">
    <label for="product_price" class="form-label"><?php echo e(__('Product Price')); ?></label>
    <input id="product_price" type="text" class="form-control <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="product_price" value="<?php echo e(old('product_price')); ?>">
         <?php $__errorArgs = ['Product Price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="product_quan" class="form-label"><?php echo e(__('Product Quantity')); ?></label>
    <input id="product_quan" type="text" class="form-control <?php $__errorArgs = ['product_quan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="product_quan" value="<?php echo e(old('product_quan')); ?>">
         <?php $__errorArgs = ['Product Quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="product_image" class="form-label"><?php echo e(__('Product Image')); ?></label>
    <input id="product_image" type="file" class="form-control <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="product_image" value="<?php echo e(old('product_image')); ?>">
         <?php $__errorArgs = ['Product Image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="product_exp" class="form-label"><?php echo e(__('Product Expiration')); ?></label>
    <input id="product_exp" type="text" class="form-control <?php $__errorArgs = ['product_exp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="product_exp" value="<?php echo e(old('product_exp')); ?>">
         <?php $__errorArgs = ['Product Expiration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
  <button type="submit" class="btn btn-primary">Add Product</button>
</form>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/clickventory/dashboard.blade.php ENDPATH**/ ?>