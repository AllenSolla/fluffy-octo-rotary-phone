<?php $__env->startSection('content'); ?>
<p></p>
<a href="#" data-toggle="modal" data-target="#category" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
<!--Category Modal -->
<div class="modal fade" id="category" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="category">Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
      <form action="/category" method="post">
      <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="category" class="form-label"><?php echo e(__('Category Name')); ?></label>
    <input id="category" type="text" class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="category" value="<?php echo e(old('category')); ?>">
         <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
  <div class="form-group">
  <label for="parent_cat" class="form-label"><?php echo e(__('Parent category')); ?></label>
    <input id="parent_cat" type="text" class="form-control <?php $__errorArgs = ['parent_cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="parent_cat" value="<?php echo e(old('parent_cat')); ?>">
         <?php $__errorArgs = ['parent_cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
  <button type="submit" class="btn btn-primary">Add Category</button>
</form>
  </div>  
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>
<!-- add modal end-->

<div class="container">

<table class="table table-hover table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Category</th>
        <th>Parent Category</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      
        <td value="<?php echo e($category->cat_id); ?>" > <?php echo e($category->cat_id); ?> </td>
        <td value="<?php echo e($category->cat_name); ?>" > <?php echo e($category->cat_name); ?> </td>
        <td value="<?php echo e($category->cat_parent); ?>" > <?php echo e($category->cat_parent); ?> </td>
        <td>
        <a href="/category/<?php echo e($category->cat_id); ?>" class="btn btn-primary"><i class="fa fa-edit">&nbsp;</i>Edit</a>
        <p></p>
        <form action="/category/<?php echo e($category->cat_id); ?>" method="post">
        <?php echo csrf_field(); ?>  <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash">&nbsp;</i>Delete</button>
        </form> 

        </td>        
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/clickventory/category.blade.php ENDPATH**/ ?>