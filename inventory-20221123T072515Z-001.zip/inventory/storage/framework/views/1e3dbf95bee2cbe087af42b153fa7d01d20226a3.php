<?php $__env->startSection('content'); ?>
<div class="container">
<form  action="/category/<?php echo e($category->cat_id); ?>" method="POST">       
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>     
<table class="table table-hover table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Category Name</th>
        <th>Parent Category</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <td value="<?php echo e($category->cat_id); ?>"><?php echo e($category->cat_id); ?>

      
      </td>
        <td>   
        <input type="edit_category" class="form-control"name="edit_category" id="edit_category" value="<?php echo e($category->cat_name); ?>"></td>
        <td>
        <input type="e_cat_parent" class="form-control"name="e_cat_parent" id="e_cat_parent" value="<?php echo e($category->cat_parent); ?>"> </td>
        <td>
        <button type="submit" class="btn btn-primary"><i class="fa fa-pencil">&nbsp;</i>Update</button> </td>      
      </tr>
 
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/clickventory/edit.blade.php ENDPATH**/ ?>