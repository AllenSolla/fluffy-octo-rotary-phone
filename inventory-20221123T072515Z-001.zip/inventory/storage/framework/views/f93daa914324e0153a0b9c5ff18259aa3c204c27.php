  
  <?php $__env->startSection('content'); ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
  <!-- Card -->
  <div calss="overlay"> <div class="loader"></div> </div>
  <p></p>
  <div class="container">
  <div class="row">
  <div class="col-md-10 mx-auto">   
  <div class="card" style="box-shadow: 0 0 25px 0 lightgrey;">
    <div class="card-header">
      <h4> New Orders </h4>
    </div>
    
    <div class="card-body">
    <!--order date-->
    <form onsubmit="return false">
    <div class="form-group row">
    <label class="col-sm-3" align="right"><?php echo e(__('Order Date')); ?></label>
    <div class="col-sm-6">
    <input type="text" readonly class="form-control form-control-sm" value="<?php echo date("Y-d-m");?>">
    </div>
    </div>
  <!--customer name-->
    <div class="form-group row">
    <label class="col-sm-3" align="right"><?php echo e(__('Customer Name')); ?></label>
    <div class="col-sm-6">
    <input type="text" class="form-control form-control-sm" name="customer_name" id="customer_name" placeholder="Enter Customer Name">
    </div>
    </div>
    
    <div class="card" style="box-shadow: 0 0 25px 0 lightgrey;">
    <div class="card-body">
    <h3>Make Order</h3>
    <table align="center" style="width:800;" id="table_field">
    <thead>
    <tr>
    <th style="text-align:center;">#</th>
    <th style="text-align:center;">Item Name</th>
    <th style="text-align:center;">Total Quantity</th>
    <th style="text-align:center;">Quantity</th>
    <th style="text-align:center;">Price</th>
    <th style="text-align:center;">Total</th>
    <th style="text-align:center;">Action</th>
    </tr>
    </thead>
    <tbody id="invoice_item">
    <tr>
    
    <td id="number">1</td>
   
    <td><select id="p_id[]" class="form-control form-control-sm pid">
    <option value="">Choose Product</option>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($products->prod_id); ?>"> <?php echo e($products->prod_name); ?> </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </td>
    <td> <input name="tqty" id="tqty[]" type="text" class="form-control form-control-sm tqty"   readonly> </td>
    <td> <input name="qty" id="qty[]" type="text" class="form-control form-control-sm qty">  </td>
    <td>  <input name="price" id="price[]" type="text" class="form-control form-control-sm price" readonly>  </td>
    <td>P<span class="amt">2000</span></td>
    <td><input type="hidden" name="pro_name[]" class="form-control form-control-sm pro_name" ></td>
    </tr>
    </tbody>
    </table>

    <script type="text/javascript">
      $(document).ready(function(){
        var i = 1;
        $('#add').click(function(){
          i++;
            $('#invoice_item').append('<tr id="row'+i+'"><td id="number">1</td><td><select id="p_id[]" class="form-control form-control-sm pid"><option value="">Choose Product</option><?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($products->prod_id); ?>"> <?php echo e($products->prod_name); ?> </option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input name="tqty" id="tqty[]" type="text" class="form-control form-control-sm tqty"  readonly></td><td><input name="qty" id="qty[]" type="text" class="form-control form-control-sm qty" ></td><td><input name="price" id="price[]" type="text" class="form-control form-control-sm price" readonly></td><td>P2000</td><td><button class="btn btn-danger remove_row" id="'+i+'"><li class="fa fa-remove"></li></button></td></tr>')
        });
        $(document).on('click', '.remove_row',function() {
          var row_id = $(this).attr("id");
          $('#row'+row_id+'').remove()
        });
        $("#invoice_item").delegate(".pid","change",function(){
          var pid = $(this).val();
          var tr = $(this).parent().parent();
          $(".overlay").show();
          $.ajax({
            url : "/index",
            method : "POST",
            dataType: "json",
            data :{index:1:id,pid},
            success : function(data){
              tr.find(".tqty").val(data["product_quan"]);
              tr.find(".pro_name").val(data["product_name"]); 
              tr.find(".qty").val(1);
              tr.find(".price").val(data["product_price"]);
              tr.find(".amt").html(tr.find(".qty").val() * tr.find(".price").val());

            }
          });
          });
        });
         
    </script>
    <!--table ends-->
    <p></p>  
    <center>
    <button class="btn btn-success" id="add"><li class="fa fa-plus"></li> &nbsp; Add </button></td>

    </center>
    </div> <!-- card body ends-->
    </div><!-- order list ends-->
    <p></p>
    <div class="form-group row">
    <label for="sub_total" class="col-sm-3 col-form-label" align="right">Sub Total</label>
    <div class="col-sm-6">
    <input type="text" name="sub_total" id="sub_total" class="form-control form-control-sm" id="sub_total">
    </div>
    </div>
  <!--GST-->
    <div class="form-group row">
    <label for="gst" class="col-sm-3 col-form-label" align="right">GST (18%)</label>
    <div class="col-sm-6">
    <input type="text" name="gst" id="gst" class="form-control form-control-sm" id="gst">
    </div>
    </div>
    <!--Discount-->
    <div class="form-group row">
    <label for="discount" class="col-sm-3 col-form-label" align="right">Discount</label>
    <div class="col-sm-6">
    <input type="text" name="discount" id="discount" class="form-control form-control-sm" id="discount">
    </div>
    </div>
  <!--Net total-->
    <div class="form-group row">
    <label for="net_total" class="col-sm-3 col-form-label" align="right">Net Total</label>
    <div class="col-sm-6">
    <input type="text" name="net_total" id="net_total" class="form-control form-control-sm" id="net_total">
    </div>
    </div>
  <!--Paid-->
    <div class="form-group row">
    <label for="paid" class="col-sm-3 col-form-label" align="right">Paid</label>
    <div class="col-sm-6">
    <input type="text" name="paid" id="paid" class="form-control form-control-sm" id="paid">
    </div>
    </div>
    <!--Due-->
    <div class="form-group row">
    <label for="due" class="col-sm-3 col-form-label" align="right">Due</label>
    <div class="col-sm-6">
    <input type="text" name="due" id="due" class="form-control form-control-sm" id="due">
    </div>
    </div>
  <!-- Payment Method-->
    <div class="form-group row">
    <label for="payment_method" class="col-sm-3 col-form-label" align="right">Payment Method</label>
    <div class="col-sm-6">
    <select name="payment_method" id="payment_method" class="form-control form-control-sm">
    <option value="cash"></option>
    <option value="card">Card</option>
    <option value="draft">Draft</option>
    <option value="cheque">Cheque</option>
    </select>
    </div>
    </div>
    <center>
    <input type="submit" id="order_form" style="width:150px;" class="btn btn-info"  value="Order" >
    <input type="submit" id="print_invoice" style="width:150px;" class="btn btn-success d-none" value="Print Invoice">
    </center>
    </form>
    </div>
  </div>
  </div></div></div>
  </html>
  </body>
  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/allen/inventory/resources/views/clickventory/order.blade.php ENDPATH**/ ?>