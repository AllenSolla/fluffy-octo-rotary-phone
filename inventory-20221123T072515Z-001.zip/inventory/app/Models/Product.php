<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $fillable = [
        'prod_name',
        'cat_id',
        'brand_id',
        'prod_price',
        'prod_quan',
        'prod_img',
        'prod_exp',
    ];
    protected $primaryKey='prod_id';
    
}
