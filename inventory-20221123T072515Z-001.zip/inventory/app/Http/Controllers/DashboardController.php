<?php

namespace App\Http\Controllers;
use App\Models\Category;
use App\Models\Brand;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth']);
    }
    public function index()
    {
        $categories = Category:: all();
        $brands = Brand:: all();
        return view('clickventory.dashboard',compact('categories', 'brands'));
    }

}