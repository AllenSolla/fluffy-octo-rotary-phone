<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function __construct()
    {
        $this->middleware(['guest']);
    }
    public function index()
    {
        return view('auth.register');
    }
    public function store(Request $request) 
    {
    
        $this->validate($request, [
        'first_name' => 'required|max:255',
        'last_name' => 'required|max:255',
        'Address' => 'required|max:255',
        'Contact' => 'required|max:255',
        'user_type' => 'required|max:255',
        'email' => 'required|email|max:255|unique:users,email',
        'password' => 'required|confirmed',
        ]);
       User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'comp_add' => $request->Address,
            'u_num' => $request->Contact,
            'u_type' => $request->user_type,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            ]);

            auth()->attempt($request->only('email', 'password'));
            return redirect()->route('dashboard');
    }

}
