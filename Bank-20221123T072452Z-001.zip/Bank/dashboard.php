@extends('layouts.layout')
@section('content')
<!-- Side Card -->
<br>
<div class="container">
    <div class="row">   
        <div class="col-md-4">
        <div class="card mx-auto" style="width: 20rem;">
        <img class="card-img-top mx-auto" src="img/Dashboard.gif"  style="width:100%;" alt="Login icon">
        <div class="card-body"> 
        <h5 class="card-title">Profile Info</h5>
        <p class="card-text"><i class="fa fa-user">&nbsp;</i>{{auth()->user()->first_name}}</p>
        <p class="card-text"><i class="fa fa-user">&nbsp;</i>{{auth()->user()->u_type}}</p>
        <p class="card-text">Last Login : xxxx-xx-xx</p>
        <a href="#" class="btn btn-primary"> <i class="fa fa-eye">&nbsp;</i> View Users</a>
        <a href="Edit_profile" class="btn btn-primary"> <i class="fa fa-edit">&nbsp;</i> Edit Profile</a>
</div>
</div>
</div>
<div class="col-md-8">
    <div class="jumbotron" style="width:100%;height:100%;">
    <h1>WELCOME</h1>
    <div class="row">
    <div class="col-sm-6">
    <iframe src="http://free.timeanddate.com/clock/i7m5eiuz/n145/szw110/szh110/cf100/hnce1ead6" frameborder="0" width="110" height="110"></iframe>
    </div>
    
    <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">New Orders</h5>
        <p class="card-text">Here you can make new Orders and Invoice.</p>
        <a href="order" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>New Orders</a>
      </div>
    </div>
    </div>
    </div>
</div>
</div>
</div>
</div>
<!-- Card -->
<p></p>
<p></p>
<div class="container">
<div class="row">
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Categories</h5>
        <p class="card-text">Here you can add and manage categories.</p>
        <a href="#" data-toggle="modal" data-target="#category" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
        <a href="/category" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Brands</h5>
        <p class="card-text">Here you can add and manage brands.</p>
        <a href="#" data-toggle="modal" data-target="#brand" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i>Add</a>
        <a href="/brand" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
<div class="col-md-4 ">
<div class="card">
      <div class="card-body">
        <h5 class="card-title">Products</h5>
        <p class="card-text">Here you can add and manage products.</p>
        <a href="#" data-toggle="modal" data-target="#product" class="btn btn-primary"><i class="fa fa-plus">&nbsp;</i> Add</a>
        <a href="/product" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i> Manage</a>
      </div>
    </div>
</div>
</div>
</div>
<!--Category Modal -->
<div class="modal fade" id="category" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="category">Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
      <form action="/category" method="post">
      @csrf
    <div class="form-group">
    <label for="category" class="form-label">{{ __('Category Name') }}</label>
    <input id="category" type="text" class="form-control @error('category') is-invalid @enderror" name="category" value="{{ old('category') }}">
         @error('category')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>
  <div class="form-group">
  <label for="parent_cat" class="form-label">{{ __('Parent category') }}</label>
    <input id="parent_cat" type="text" class="form-control @error('parent_cat') is-invalid @enderror" name="parent_cat" value="{{ old('parent_cat') }}">
         @error('parent_cat')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
      </div>
  <button type="submit" class="btn btn-primary">Add Category</button>
</form>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>

<!--Brand Modal -->
<div class="modal fade" id="brand" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="brand">Brand</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<div class="modal-body">
      <form action="/brand" method="post">
      @csrf
    <div class="form-group">
    <label for="brand" class="form-label">{{ __('Brand Name') }}</label>
    <input id="brand" type="text" class="form-control @error('brand') is-invalid @enderror" name="brand" value="{{ old('brand') }}">
         @error('Brand Name')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>
  <button type="submit" class="btn btn-primary">Add Brand</button>
</form>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>

<!--Product Modal -->
<div class="modal fade" id="product" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="product">Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<div class="modal-body">
      <form action="/product" method="post">
      @csrf
    <div class="form-group">
    <label for="product" class="form-label">{{ __('Product Name') }}</label>
    <input id="product" type="text" class="form-control @error('prouct') is-invalid @enderror" name="product" value="{{ old('product') }}">
         @error('Product Name')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
        <div class="form-group">
    <label>{{ __('Category') }}</label>
    <select name="product_cat" id="product_cat" class="form-control">
    @foreach($categories as $category)
      <option value="{{ $category->cat_id}}">{{ $category->cat_name }}</option>
        @endforeach
    </select>
       </div> 
       <label>{{ __('Brand') }}</label>
    <select name="product_brand" id="product_brand" class="form-control" >
        @foreach($brands as $brand)
            <option value="{{ $brand->brand_id}}" >{{ $brand->brand }}</option>
        @endforeach
    </select>
       </div> 
        <div class="form-group">
    <label for="product_price" class="form-label">{{ __('Product Price') }}</label>
    <input id="product_price" type="text" class="form-control @error('product_price') is-invalid @enderror" name="product_price" value="{{ old('product_price') }}">
         @error('Product Price')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>

<div class="form-group">
    <label for="product_quan" class="form-label">{{ __('Product Quantity') }}</label>
    <input id="product_quan" type="text" class="form-control @error('product_quan') is-invalid @enderror" name="product_quan" value="{{ old('product_quan') }}">
         @error('Product Quantity')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>

<div class="form-group">
    <label for="product_image" class="form-label">{{ __('Product Image') }}</label>
    <input id="product_image" type="file" class="form-control @error('product_image') is-invalid @enderror" name="product_image" value="{{ old('product_image') }}">
         @error('Product Image')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>

<div class="form-group">
    <label for="product_exp" class="form-label">{{ __('Product Expiration') }}</label>
    <input id="product_exp" type="text" class="form-control @error('product_exp') is-invalid @enderror" name="product_exp" value="{{ old('product_exp') }}">
         @error('Product Expiration')
        <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
        </span>
        @enderror
</div>
  <button type="submit" class="btn btn-primary">Add Product</button>
</form>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>  
</div>
@endsection