<?php

class Transaction extends Db {

    public function operation($bal,$amount,$transaction) 
    {
        switch($transaction) {
            case 'withdraw':
                return $bal - $amount;
            break;
            case 'deposit':
                return $bal + $amount;
            break;
            case 'transferadd':
                return $bal + $amount;
            break;
            case 'transfersub':
                return $bal - $amount;
            break;

        }

    }

    protected function setReqDeposit($users_fk,$accnum,$first_name,$middle_name, $last_name, $amount,$deposit,$trans_category,$id_check) 
    {
        $sql = "SELECT * FROM other_details WHERE account_num = ?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$accnum]);
        if ($row = $stmt->fetch()) {
            
            $sql = "SELECT * FROM users WHERE first_name = ? AND middle_name = ? AND last_name = ?";
            $stmt = $this->connect()->prepare($sql);
            $stmt->execute([$first_name, $middle_name, $last_name]);
            if ($row1 = $stmt->fetch()) {
                if($row['users_fk'] == $row1['users_id']) {
                    $sql = "SELECT * FROM users WHERE users_id = ?";
                    $stmt = $this->connect()->prepare($sql);
                    $stmt->execute([$users_fk]);
                    $teller = $stmt->fetch();

                    if ($row['users_fk'] != $users_fk){
                        if ($row['balance'] <= 0) {
                            $current = $row['balance'] + 0;
                            return "<li class='text-danger'>Transaction Failed: Current Balance is {$current}</li>";
                        } 

                    $result = $this->operation($row['balance'], $amount, $deposit);
                    $sql = "UPDATE other_details SET balance = ? WHERE account_num = ?";
                    $stmt = $this->connect()->prepare($sql);
                    $stmt->execute([$result,$accnum]);
                    $tellerName = $teller['first_name']. " ". $teller['middle_name'] . " ". $teller['last_name'];
                    
                    $sql = "INSERT INTO `transaction`( `users_fk`, `acc_num`,`acc_name`, `amount`, `trans_type`, `trans_category`, `check_num`) VALUES (?,?,?,?,?,?,?)";
                    $stmt = $this->connect()->prepare($sql);
                    if($stmt->execute([$users_fk,$accnum,$tellerName,$amount,$deposit,$trans_category,$id_check])) {
                        return Validation::flash("Successful Message", "Succefully Deposit");
                    }
                } else {
                    return "Invalid Transasction";
                }
            } else {
                return "Check your Account Name or Number";
            }
                } else {
                return "Check your Account Name";
            }
        } else {
            return "Check your Account Number";
        }
    }


    protected function setReqWithdraw($users_fk,$accnum,$first_name, $middle_name, $last_name,$amount,$withdraw)
    {
        $sql = "SELECT * FROM other_details WHERE account_num = ?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$accnum]);
        if ($row = $stmt->fetch()) {
            
            $sql = "SELECT * FROM users WHERE first_name = ? AND middle_name = ? AND last_name = ?";
            $stmt = $this->connect()->prepare($sql);
            $stmt->execute([$first_name, $middle_name, $last_name]);
            if ($row1 = $stmt->fetch()) {
                if($row['users_fk'] == $row1['users_id']) {
                    $sql = "SELECT * FROM users WHERE users_id = ?";
                    $stmt = $this->connect()->prepare($sql);
                    $stmt->execute([$users_fk]);
                    $teller = $stmt->fetch();

                    if ($row['users_fk'] != $users_fk){
                        if ($row['balance'] <= 0) {
                            $current = $row['balance'] + 0;
                            return "<li class='text-danger'>Transaction Failed: Current Balance is {$current}</li>";
                        } elseif ($amount > $row['balance']) {
                            return "<li class='text-danger'>Amount must not be greater than your Current Balance</li>";
                        }

                        $sql = "SELECT balance FROM other_details WHERE  account_num = ?";
                        $stmt = $this->connect()->prepare($sql);
                        $stmt->execute([$accnum]);

                        $tellerName = $teller['first_name']. " ". $teller['middle_name'] . " ". $teller['last_name'];

                        if ($row =  $stmt->fetch()) 
                        {
                            $result = $this->operation($row['balance'], $amount, $withdraw);
                            $sql = "UPDATE other_details SET balance = ? WHERE account_num = ?";
                            $stmt = $this->connect()->prepare($sql);
                            $stmt->execute([$result,$accnum]);
                        }
                        $sql = "INSERT INTO `transaction`( `users_fk`, `acc_num`,`acc_name`, `amount`, `trans_type`) VALUES (?,?,?,?,?)";
                        $stmt = $this->connect()->prepare($sql);
                        if ($stmt->execute([$users_fk,$accnum,$tellerName,$amount,$withdraw])){
                            return Validation::flash("Successful Message", "Succefully Withdraw");
                        }
                    } else {
                        return "Invalid Transasction";
                        }
                        } else {
                        return "Check your Account Name or Number";
                        }
                        } else {
                        return "Check your Account Name";
                        }
                        } else {
                        return "Check your Account Number";
                    }
    }

    protected function setReqTransfer($users_fk,$accnum,$first_name, $middle_name, $last_name, $amount,$transfer) 
    {

        $sql = "SELECT * FROM other_details WHERE account_num = ?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$accnum]);
        if ($row = $stmt->fetch()) {
            
            $sql = "SELECT * FROM users WHERE first_name = ? AND middle_name = ? AND last_name = ?";
            $stmt = $this->connect()->prepare($sql);
            $stmt->execute([$first_name, $middle_name, $last_name]);
            if ($row1 = $stmt->fetch()) {
                
                if($row['users_fk'] == $row1['users_id']) {
                    
                    $sql = "SELECT * FROM users, other_details WHERE other_details.users_fk = ? AND users.users_id = other_details.users_fk";
                    $stmt = $this->connect()->prepare($sql);
                    $stmt->execute([$users_fk]);
                    $senderId = $stmt->fetch();
                    
                    if ($row['users_fk'] != $users_fk){
                        if ($senderId['balance'] <= 0) {
                            $current = $senderId['balance'] + 0;
                            return "<li class='text-danger'>Transaction Failed: Current Balance is {$current}</li>";
                        } elseif ($amount > $senderId['balance']) {
                            return "<li class='text-danger'>Amount must not be greater than your Current Balance</li>";
                        }

                        $transferReceiver = $this->operation($row['balance'], $amount, 'transferadd');
                        $transferSender = $this->operation($senderId['balance'], $amount, 'transfersub');
                        
                        $sql = "UPDATE other_details SET balance = ? WHERE users_fk = ?";
                        $stmt = $this->connect()->prepare($sql);
                        $stmt->execute([$transferSender, $users_fk]);
                        
                        $receiverName = $row1['first_name']. " ". $row1['middle_name'] . " ". $row1['last_name'];
                        
                        $sql = "UPDATE other_details SET balance = ? WHERE users_fk = ?";
                        $stmt = $this->connect()->prepare($sql);
                        if($stmt->execute([$transferReceiver, $row['users_fk']])) {
                            $sql = "INSERT INTO `transaction`(`users_fk`, `acc_num`,`acc_name`, `amount`, `trans_type`) 
                            VALUES (?,?,?,?,?)";
                            $stmt = $this->connect()->prepare($sql);
                            if($stmt->execute([$users_fk,$accnum, $receiverName,$amount, $transfer]))  {
                                return Validation::flash("Successful Message", "Succefully Transfer");
                            }
                        }
                        

                    } else {
                        return "Invalid Transasction";
                    }
                } else {
                    return "Check your Account Name or Number";
                }
            } else {
                return "Check your Account Name";
            }
        } else {
            return "Check your Account Number";
        }
    }

    protected function getOwnTrans($table, $values,$acc_num)
    {
        $sql = $this->FkTrans($table, $values);
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$acc_num]);
        while ($row = $stmt->fetch())
        {
            echo "<tr>" . "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['acc_num'] . "</td>";
            echo "<td>" . $row['acc_name'] . "</td>";
            echo "<td>" . $row['users_fk'] . "</td>";
            echo "<td>" . $row['trans_type'] . "</td>";
            echo "<td>" . $row['trans_category'] . "</td>";
            echo "<td>" . $row['amount'] . "</td>" ;
            echo "<td>" . $row['date_trans'] . "</td>" . "</tr>";
    
        }
    } 

    protected function FkTrans($table, $values) 
    {
        return "SELECT * FROM $table WHERE $values";
    }
    protected function gettellerTrans($table, $values,$users_fk)
    {
        $sql = $this->FkTrans($table, $values);
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$users_fk]);
        while ($row = $stmt->fetch())
        {
            echo "<tr>" . "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['acc_num'] . "</td>";
            echo "<td>" . $row['acc_name'] . "</td>";
            echo "<td>" . $row['users_fk'] . "</td>";
            echo "<td>" . $row['trans_type'] . "</td>";
            echo "<td>" . $row['trans_category'] . "</td>";
            echo "<td>" . $row['amount'] . "</td>" ;
            echo "<td>" . $row['date_trans'] . "</td>" . "</tr>";
    
        }
    }

    protected function getAllTrans() 
    {
        $sql = "SELECT * FROM `transaction`";
        $stmt = $this->connect()->query($sql);
        while ($row = $stmt->fetch())
        {
            echo "<tr>" . "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['acc_num'] . "</td>";
            echo "<td>" . $row['acc_name'] . "</td>";
            echo "<td>" . $row['users_fk'] . "</td>";
            echo "<td>" . $row['trans_type'] . "</td>";
            echo "<td>" . $row['trans_category'] . "</td>";
            echo "<td>" . $row['amount'] . "</td>" ;
            echo "<td>" . $row['date_trans'] . "</td>" . "</tr>";
    
        }
    }
}
