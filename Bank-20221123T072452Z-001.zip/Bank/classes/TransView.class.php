<?php

class TransView extends Transaction 
{
    function showOwnTrans($table, $values,$acc_num)
    {
        $this->getOwnTrans($table, $values,$acc_num);
    }

    function showAllTrans()
    {
        $this->getAllTrans();
    }
    function getTrans($table, $values,$users_fk)
    {
        $this->gettellerTrans($table, $values,$users_fk);
    }
}