<?php

class AccountCtr extends Account {

    function createAccount($lastname,$middlename,$firstname,$exname,$email,$pwd,$gender,
    $cstatus,$housenum,$sname,$brgy,$city,$zipcode,$country,$usertype,$softdelete,$status,$teller_id,$birthday,$Mother_s,
    $Mother_m,$Mother_f,$contact_num,$account_num,$bbranch,$bal) 
    {
        $this->setAccount($lastname,$middlename,$firstname,$exname,$email,$pwd,$gender,
        $cstatus,$housenum,$sname,$brgy,$city,$zipcode,$country,$usertype,$softdelete,$status,$teller_id,$birthday,$Mother_s,
        $Mother_m,$Mother_f,$contact_num,$account_num,$bbranch,$bal);
    }
    function createpass($npass, $users_id) 
    {
     return $this->changepass($npass, $users_id);
    }
    function signin($email,$pwd) 
    {
       return $this->login($email,$pwd);
    }

    function createincAccnum()
    {
     return $this->setincAccnum('other_details','account_num','account_num','10','account_num');
    }

    function accept( $a,$b,$c, $d)
    {
        $this->acceptCus($a,$b,$c, $d);
        
    }
    function denied($a,$b,$c)
    {
        $this->deniedCus($a,$b,$c);
        
    }
    function createEmployee($lastname, $middlename, $firstname, $exname, $email, $pwd, $gender, $cstatus, $housenum, $sname, $brgy, $city, $zipcode, $country, $usertype, $softdelete, $status, $teller_id)
    {
        $this->setEmployee($lastname, $middlename, $firstname, $exname, $email, $pwd, $gender, $cstatus, $housenum, $sname, $brgy, $city, $zipcode, $country, $usertype, $softdelete, $status, $teller_id);
    }

    function tellerBtn($a, $b, $c) 
    {
        if($c == "remove")
            return $this->removeUser($a, $b);
        else 
            return $this->deactivateUser($a, $b);
    }

// function ins($a,$b,$c,$d) {
//     $this->setem($a,$b,$c,$d);
// }   
}