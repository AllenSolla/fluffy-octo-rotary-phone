<?php

class Validation extends Account
{

    protected $errors = array();
    private $passed = false;

    function check($source, $items = array())
    {
        foreach ($items as $item => $rules) {

            foreach ($rules as $rule => $rule_value) {
                $value = trim($source[$item]);

                if ($rule === 'required' && empty($value)) {
                    $this->addError("{$this->removeUnderScore($item)} is required");
                } else if (!empty($value)) {
                    switch ($rule) {
                        case 'min':
                            if (strlen($value) < $rule_value) {
                                $this->addError("{$this->removeUnderscore($item)} must be a minimum of {$this->removeUnderscore($rule_value)}");
                            }
                            break;
                        case 'max':
                            if (strlen($value) > $rule_value) {
                                $this->addError("{$this->removeUnderscore($item)} must be a maximum of {$this->removeUnderscore($rule_value)}");
                            }
                            break;

                        case 'youremail':
                            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                                $this->addError("Email must be valid {$this->removeUnderscore($rule_value)}");
                            }
                            break;
                        case 'lettersAndWhiteSpaces':
                            if (!preg_match("/^[a-zA-Z-' -\/]*$/", $value)) {
                                $this->addError("{$this->removeUnderscore($item)} only letters and white spaces are allowed!");
                            }
                            break;
                        case 'unique':
                            if ($this->queryEmail($value)) {
                                $this->addError("{$this->removeUnderscore($item)} must be {$this->removeUnderscore($rule_value)}");
                            }
                            break;
                        case 'confirm_password':
                            if ($value != $source[$rule_value]) {
                                $this->addError("{$this->removeUnderscore($rule_value)} must match {$this->removeUnderscore($item)}");
                            }
                            break;
                        // case 'confirm_pin':
                        //     if ($value != $source[$rule_value]) {
                        //         $this->addError("{$this->removeUnderscore($rule_value)} must match {$this->removeUnderscore($item)}");
                        //     }
                        //     break;
                        case 'number':
                            if (!preg_match('/^[0-9]*$/', $value)) {
                                $this->addError("{$this->removeUnderscore($item)} must numbers only");
                            }
                            break;
                        // case 'old_pin':
                        //     if ($value == Account::generatePin()) {
                        //         $this->addError("Please change your {$this->removeUnderscore($rule_value)}");
                        //     }
                            // break;
                        case 'old_password':
                            if (Hash::encryptPassword($value) !== $this->queryPassword($_SESSION['id'])) {
                                $this->addError("Wrong {$this->removeUnderscore($rule_value)}");
                            }
                            break;
                        case 'new_password':
                            if (Hash::encryptPassword($value) === $this->queryPassword($_SESSION['id'])) {
                                $this->addError("Change your {$this->removeUnderscore($rule_value)} to {$this->removeUnderscore($item)}");
                            }
                            break;
                        // case 'confirm_password':
                        //     if (Hash::encryptPassword($value) !== Hash::encryptPassword($source[$rule_value])) {
                        //         $this->addError("{$this->removeUnderscore($rule_value)} must match {$this->removeUnderscore($item)}");
                        //     }
                        //     break;
                    }
                }
            }
        }

        if (empty($this->errors)) {
            $this->passed = true;
        }

        return $this;
    }

    protected function addError($error)
    {
        $this->errors[] = $error;
    }

    function errors()
    {
        return $this->errors;
    }

    function passed()
    {
        return $this->passed;
    }
    protected function removeUnderscore($str)
    {
        return str_replace("_", " ", $str);
    }

    public static function flash($name = '', $message = '', $class = 'alert alert-success')
    {
        if (!empty($name)) {
            //No message, create it
            if (!empty($message) && empty($_SESSION[$name])) {
                if (!empty($_SESSION[$name])) {
                    unset($_SESSION[$name]);
                }
                if (!empty($_SESSION[$name . '_class'])) {
                    unset($_SESSION[$name . '_class']);
                }
                $_SESSION[$name] = $message;
                $_SESSION[$name . '_class'] = $class;
            }
            //Message exists, display it
            elseif (!empty($_SESSION[$name]) && empty($message)) {
                $class = !empty($_SESSION[$name . '_class']) ? $_SESSION[$name . '_class'] : 'success';
                echo '<div class="' . $class . '" id="msg-flash">' . $_SESSION[$name] . '</div>';
                unset($_SESSION[$name]);
                unset($_SESSION[$name . '_class']);
            }
        }
    }
}
