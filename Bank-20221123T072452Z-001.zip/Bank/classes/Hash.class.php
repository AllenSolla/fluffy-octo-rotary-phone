<?php
class Hash
{
    public static function encryptPassword($password)
    {
        return hash("sha512", $password);
    }
}