<?php 
class TransCtr extends Transaction
{
    function storeDeposit($user_fk,$accnum, $first_name, $middle_name, $last_name, $amount,$deposit,$trans_category,$id_check) {
        return $this->setReqDeposit($user_fk,$accnum, $first_name, $middle_name, $last_name, $amount,$deposit,$trans_category,$id_check);
    }

    function storeWithdraw($user_fk,$accnum,$first_name, $middle_name, $last_name,$amount,$withdraw) 
    {
        return $this->setReqWithdraw($user_fk,$accnum,$first_name, $middle_name, $last_name,$amount,$withdraw);
    }

    function storeTransfer($user_fk,$accnum,$acc_name,$amount,$transfer,$trans_category,$id_check) 
    {
        return $this->setReqTransfer($user_fk,$accnum,$acc_name,$amount,$transfer,$trans_category,$id_check);
    }

}