<?php
class AccountView extends Account {

     function showSingleCus($user_type) {
         $row =  $this->getSingleCus($user_type);
         
       $_SESSION['balance']. $_SESSION['account_num'];

       

    }

    function showAllCus()
    {
        $this->getAllCus();
        
    }

    function accept()
    {
      $this->acceptedCus();
    }

    function employee()
    {
      $this->getteller();
    }
    function allemployee()
    {
      $this->getall();
    }

}