<?php
class Account extends Db {

   public $email;
   protected $pin;

   protected function queryEmail($email)
   {
       $sql = "SELECT * FROM users WHERE email = ?";
       $stmt = $this->connect()->prepare($sql);
       $stmt->execute([$email]);
       while ($row = $stmt->fetch()) {
           return $row['email'];
       }
   }

   protected function query($table, $condition)
   {
       return "SELECT * FROM {$table} WHERE {$condition}";
   }

   protected function queryPassword($id)
   {
       $sql = "SELECT password FROM users WHERE id = ?";
       $stmt = $this->connect()->prepare($sql);
       $stmt->execute([$id]);
       while ($row = $stmt->fetch()) {
           return $row['pwd'];
       }
   }
 private function emailExist($email) 
 {
   $sql = "SELECT * FROM users WHERE email = ?";
   $stmt = $this->connect()->prepare($sql);
   $stmt->execute([$email]);
   $result = $stmt->fetch();

   if($result > 0) 
   {
      return true;
   }
 }
   
 protected function setAccount($lastname,$middlename,$firstname,$exname,$email,$pwd,$gender,
 $cstatus,$housenum,$sname,$brgy,$city,$zipcode,$country,$usertype,$softdelete,$status,$teller_id,$birthday,$Mother_s,
 $Mother_m,$Mother_f,$contact_num,$account_num,$bbranch,$bal)
 {
   if ($this->emailExist($email))
   {   
   }
   else {
   $sql= "INSERT INTO `users`(`last_name`, `middle_name`, `first_name`, `extension_name`, `email`, `pwd`, 
   `gender`, `civil_status`, `house_num`, `street`, `baranggay`, `Municipality`, `zip_code`, `country`, `user_type`, `soft_delete`, `status`,`teller_id`) 
   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   $stmt = $this->connect()->prepare($sql);
   if ($stmt->execute([$lastname,$middlename,$firstname,$exname,$email,$pwd,$gender,
   $cstatus,$housenum,$sname,$brgy,$city,$zipcode,$country,$usertype,$softdelete,$status,$teller_id])) {
      $sql = "SELECT users_id FROM  users ORDER BY users_id DESC;";
      $stmt = $this->connect()->prepare($sql);
      $stmt->execute();
      while ($row = $stmt->fetch()) {
         $id = $row['users_id'];
         $sql = "INSERT INTO `other_details`(`users_fk`, `birthday`, `Mother_s`, `Mother_m`, `Mother_f`, 
       `Contact_num`,`account_num`, `balance`,`bank_brach`) VALUES (?,?,?,?,?,?,?,?,?)";
         $stmt = $this->connect()->prepare($sql);
         if ($stmt->execute([$id,$birthday,$Mother_s,
         $Mother_m,$Mother_f,$contact_num,$account_num,$bal,$bbranch])) 
         {
             header("Location: Approval.php");
         }
      }
    }
   }
}
protected function login($email,$pwd) 
{
   $this->email = $email;
   $this->pwd = $pwd;

   $sql = "SELECT * FROM users WHERE email = ? AND pwd = ?";
   $stmt = $this->connect()->prepare($sql);
   $stmt->execute([$this->email,$this->pwd]);
   if($row = $stmt->fetch()) 
   {   
      if( $row['status'] == 0 ) 
      {        
         header("Location: Approval.php");
      }
      if( $row['status'] == 1 ) 
      {
         $this->getSingleCus($row['user_type']);
         header("Location: Dashboard.php");
      } 
   }else {
      return "<li class='text-danger'>Check your Email or Password!</li>";
   }  
}

public function getSingleCus($user_type) 
   {
      
      if ($user_type == 1 ) {
         $sql = "SELECT * FROM users, other_details WHERE users.email = ? AND users.pwd = ? AND users.users_id = other_details.users_fk";
      } else {
         $sql = "SELECT * FROM users WHERE email = ? AND pwd = ?";
      }

      $stmt = $this->connect()->prepare($sql);
      $stmt->execute([$this->email, $this->pwd]);
      while($row = $stmt->fetch()) 
      {
         if ($row['status'] == 1){
            $_SESSION['account_num'] = $row['account_num'];
            $_SESSION['first_name'] = $row['first_name'];
            $_SESSION['last_name'] = $row['last_name'];
            $_SESSION['middle_name'] = $row['middle_name'];
            $_SESSION['balance'] = $row['balance'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['user_type'] = $row['user_type'];
            $_SESSION['status'] = $row['status'];
            $_SESSION['pwd'] = $row['pwd'];
            $_SESSION['users_fk'] = $row['users_fk']; 
            $_SESSION['users_id'] = $row['users_id'];
            $_SESSION['user_type'] = $row['user_type'];
            $_SESSION['teller_id'] = $row['teller_id'];
            $_SESSION['extension_name'] = $row['extension_name'];
            $_SESSION['house_num'] = $row['house_num'];
            $_SESSION['street'] = $row['street'];
            $_SESSION['baranggay'] = $row['baranggay'];
            $_SESSION['Municipality'] = $row['Municipality'];
            $_SESSION['country'] = $row['country'];
            $_SESSION['zip_code'] = $row['zip_code'];

         } else {
            $_SESSION['first_name'] = $row['first_name'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['user_type'] = $row['user_type'];
            $_SESSION['status'] = $row['status'];
            $_SESSION['users_fk'] = $row['users_fk']; 
            $_SESSION['id'] = $row['id'];
            $_SESSION['teller_id'] = $row['teller_id'];
            $_SESSION['extension_name'] = $row['extension_name'];
            $_SESSION['house_num'] = $row['house_num'];
            $_SESSION['street'] = $row['street'];
            $_SESSION['baranggay'] = $row['baranggay'];
            $_SESSION['Municipality'] = $row['Municipality'];
            $_SESSION['country'] = $row['country'];
            $_SESSION['zip_code'] = $row['zip_code'];    
         }
         return $_SESSION;
      }
   }

   protected function changepass($npass,$users_id)
   {  
      $sql = "UPDATE users SET pwd = ? WHERE users_id = ?";
      $stmt = $this->connect()->prepare($sql);
      if ($stmt->execute([$npass, $users_id]))
      {
         return Validation::flash("Successful Message", "Succefully Change");
      }
   }

   public static function logout()
   {
      if(session_destroy()) 
      {
         header("Location: index.php");
      }
   }
   protected function setincAccnum($table, $column, $field, $number1, $trans)
    {
        $sql = "SELECT * FROM $table ORDER BY $column DESC LIMIT 1";
        $stmt = $this->connect()->query($sql);
        if ($stmt->rowCount() < 1) 
        {
            if ($trans == "account_num")
                return "0000000001";
            else
                return "000000000001";
        }
        $stmt->execute();
      while ($row = $stmt->fetch()) 
        {
            $field = $row[$field];
            $generate_account_number = intval($field);
            return str_pad($generate_account_number + 1, $number1, 0, STR_PAD_LEFT);
            // }
        }
    }
    protected function setEmployee($lastname,$middlename,$firstname,$exname,$email,$pwd,$gender,
    $cstatus,$housenum,$sname,$brgy,$city,$zipcode,$country,$usertype,$softdelete,$status,$teller_id)
    {
      $sql= "INSERT INTO `users`(`last_name`, `middle_name`, `first_name`, `extension_name`, `email`, `pwd`, 
      `gender`, `civil_status`, `house_num`, `street`, `baranggay`, `Municipality`, `zip_code`, `country`, `user_type`, `soft_delete`, `status`,`teller_id`) 
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      $stmt = $this->connect()->prepare($sql);
      $stmt->execute([$lastname,$middlename,$firstname,$exname,$email,$pwd,$gender,
      $cstatus,$housenum,$sname,$brgy,$city,$zipcode,$country,$usertype,$softdelete,$status,$teller_id]);
    }

    protected function getAllCus()
    {
      $sql = "SELECT * FROM users, other_details WHERE users.users_id = other_details.users_fk";
      $stmt = $this->connect()->query($sql);
      $stmt->execute();
      while ($row = $stmt->fetch()) 
      {
         if ($row['status'] == 0) 
         {
            echo "<tr>" . "<td>" . $row['last_name'] . "</td>";
            echo "<td>" . $row['middle_name'] . "</td>";
            echo "<td>" . $row['first_name'] . "</td>";
            echo "<td>" . $row['extension_name'] . "</td>";
            echo "<td>" . $row['house_num'] . "</td>";
            echo "<td>" . $row['street'] . "</td>" ;
            echo "<td>" . $row['baranggay'] . "</td>" ;
            echo "<td>" . $row['Municipality'] . "</td>" ;
            echo "<form method='POST'>";
            echo "<input type='hidden' value='".$_SESSION['id']."' name='teller_id'>";
            echo "<td><input type='text' name='bal'></td>";
            echo "<input type='hidden' value='1' name='status'>" ;
            echo "<td>" . "<button type='submit' class='btn btn-success text-white' name='accept' value='".$row['users_id']."'>Accept</button>"  . "</form></td>";
            echo "<td>" . "<form method='POST'><input type='hidden' value='6' name='status'><button type='submit' class='btn btn-danger text-white' name='denied' value='".$row['id']."'>Denied</button>" . "</form>"  . "</td>" . "</tr>" ;
         }    
      }   
    }

    protected function acceptedCus()
   {
    $sql = "SELECT * FROM users, other_details WHERE users.users_id = other_details.users_fk";
    $stmt = $this->connect()->query($sql);
    $stmt->execute();
    while ($row = $stmt->fetch()) 
    {
       if ($row['status'] == 1) 
       {
         echo "<tr>" . "<td>" . $row['last_name'] . "</td>";
         echo "<td>" . $row['middle_name'] . "</td>";
         echo "<td>" . $row['first_name'] . "</td>";
         echo "<td>" . $row['extension_name'] . "</td>";
         echo "<td>" . $row['house_num'] . "</td>";
         echo "<td>" . $row['street'] . "</td>" ;
         echo "<td>" . $row['baranggay'] . "</td>" ;
         echo "<td>" . $row['Municipality'] . "</td>" ;
       }
    }
   }
    protected function acceptCus($a,$b,$c, $d)
    {
      if(isset( $_POST['accept'] ))
      { 
        $sql = "UPDATE users SET status = ?, teller_id = ? WHERE users_id = ?";
        $stmt = $this->connect()->prepare($sql);
        if($stmt->execute([$a,$b,$c])) {
           $sql = "UPDATE other_details SET balance = ? WHERE users_fk = ?";
           $stmt = $this->connect()->prepare($sql);
           $stmt->execute([$d, $c]); 
               
        }
      }
    }
    protected function deniedCus($a,$b,$c)
    {
      if (isset( $_POST['denied'] ))
      {
        $sql = "UPDATE users SET status = ?, teller_id = ? WHERE id = ?";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$a,$b,$c]);  
      }
    }

    protected function getteller()
    {
      $sql = "SELECT * FROM users";
      $stmt = $this->connect()->query($sql);
      $stmt->execute();
      while ($row = $stmt->fetch()) 
      {
         if($row['user_type'] == 2) 

         {
            if ($row['status'] == 1 && $row['soft_delete'] == 0) {
               echo "<tr>";
               echo "<td>" . $row['first_name'] . "</td>";
               echo "<td>" . $row['middle_name'] . "</td>";
               echo "<td>" . $row['last_name'] . "</td>";
               echo "<td>" . $row['email'] . "</td>";
               echo "<td>" . $row['gender'] . "</td>";
               echo "<td>" . $row['civil_status'] . "</td>" ;
               echo "<td>" . "<form method='POST'><button type='submit' class='btn btn-danger text-white' name='remove' value='".$row['users_id']."'>Remove</button> <button type='submit' class='btn btn-danger text-white' name='deactivate' value='".$row['users_id']."'>Deactivate</button></form>"  . "</form></td>";         
            }
         }

      }

    }

    protected function removeUser($a, $b)
    {
        $sql = "UPDATE users SET soft_delete = ? WHERE users_id = ?";
        $stmt = $this->connect()->prepare($sql);
        if ($stmt->execute([$a, $b])) {
            return Validation::flash("Successful Message", "Successfully Remove Teller");
        }
    }

    protected function deactivateUser($a, $b)
    {
        $sql = "UPDATE users SET status = ? WHERE users_id = ?";
        $stmt = $this->connect()->prepare($sql);
        if ($stmt->execute([$a, $b])) {
            return Validation::flash("Successful Message", "Successfully Deactivate Teller");
        }
    }

    protected function getall()
    {
      $sql = "SELECT * FROM users";
      $stmt = $this->connect()->query($sql);
      $stmt->execute();
      while ($row = $stmt->fetch()) 
      {
         if( $row['user_type'] == 3) 

         {
            if ($row['status'] == 1 && $row['soft_delete'] == 0) {
               echo "<tr>";
               echo "<td>" . $row['first_name'] . "</td>";
               echo "<td>" . $row['middle_name'] . "</td>";
               echo "<td>" . $row['last_name'] . "</td>";
               echo "<td>" . $row['email'] . "</td>";
               echo "<td>" . $row['gender'] . "</td>";
               echo "<td>" . $row['civil_status'] . "</td>" ;
               echo "<td>" . "<form method='POST'><button type='submit' class='btn btn-danger text-white' name='remove' value='".$row['users_id']."'>Remove</button> <button type='submit' class='btn btn-danger text-white' name='deactivate' value='".$row['users_id']."'>Deactivate</button></form>"  . "</form></td>";         
            }

    }
   }
    }

}