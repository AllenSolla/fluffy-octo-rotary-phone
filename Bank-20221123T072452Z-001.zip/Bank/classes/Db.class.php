<?php

class Db {

    private $dbhost = "localhost";
    private $user = "root";
    private $password = "";
    private $dbname = "bank";

     protected function connect() {
        $dsn = 'mysql:host='.$this->dbhost.';dbname='.$this->dbname;
        $pdo = new PDO($dsn, $this->user, $this->password);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
        
    }

}





