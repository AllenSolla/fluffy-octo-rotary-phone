<?php

include '../views/layout.php';
?>
   <br>
   <?php
                if( $_SESSION['user_type'] == 3) : 
                ?>
<center>
<div class="col-md-20">
  <div class="jumbotron bg-dark" style="width:95%;height:100%;">
    <table class="table table-striped table-dark">
      <thead>
       <tr>
       <th class="text-warning">Last name</th>
        <th class="text-warning">First name</th>
        <th class="text-warning">Middle name</th>
        <th class="text-warning">Email</th>
        <th class="text-warning">Gender</th>
        <th class="text-warning">Civil Status</th>
        <th class="text-warning">Action</th>
       </tr>
      </thead>
      <tbody>
       <?php 
       if(isset($_POST['remove'])) {
        $remove = new AccountCtr();
        $remove->tellerBtn(5, $_POST['remove'], "remove");
        
      } elseif(isset($_POST['deactivate'])) {
         $deactivate = new AccountCtr();
         $deactivate->tellerBtn(6, $_POST['deactivate'], "deactivate");

       }

        $users_fk = $_SESSION['users_fk'];
        $sTrans = new AccountView();
        $sTrans->employee();
        ?>
      </tbody>
    </table>
                  
    </div>
  </div>
  <?php endif?>
  <?php
if( $_SESSION['user_type'] == 4) : 
                ?>
  <center>
<div class="col-md-20">
  <div class="jumbotron bg-dark" style="width:95%;height:100%;">
    <table class="table table-striped table-dark">
      <thead>
       <tr>
       <th class="text-warning">Last name</th>
        <th class="text-warning">First name</th>
        <th class="text-warning">Middle name</th>
        <th class="text-warning">Email</th>
        <th class="text-warning">Gender</th>
        <th class="text-warning">Civil Status</th>
        <th class="text-warning">Action</th>
       </tr>
      </thead>
      <tbody>
       <?php 
       if(isset($_POST['remove'])) {
        $remove = new AccountCtr();
        $remove->tellerBtn(5, $_POST['remove'], "remove");
        
      } elseif(isset($_POST['deactivate'])) {
         $deactivate = new AccountCtr();
         $deactivate->tellerBtn(6, $_POST['deactivate'], "deactivate");

       }
       
        $users_fk = $_SESSION['users_fk'];
        $sTrans = new AccountView();
        $sTrans->allemployee();
        ?>
      </tbody>
    </table>
</center>                 
    </div>
  </div>
  <?php endif?>