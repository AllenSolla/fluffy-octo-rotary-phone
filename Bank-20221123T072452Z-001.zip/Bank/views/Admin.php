<?php
include '../includes/class-autoloader.inc.php';
session_start();
if(!isset($_SESSION['email']) && !isset($_SESSION['pwd'])) 
{
  header("Location: index.php");
}
if(isset($_POST['logout'])) 
  Account::logout();
?>
<!-- Change Pass Modal -->
<!-- <div class="modal fade" id="pass">
    <form method="POST">
    
    //if(isset($_POST['cpass'])) {
    //$cPass = new AccountCtr();
    //$cPass->createpass( sha1($_POST['npass']), $_SESSION['id']); 
    //}
  
  <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header text-center">
            <h3 class="modal-title w100 dark-grey-text font-weight-bold">Change Password</h3>   
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>        
          </div>
             <div class="modal-body mx-4">
             <div class="md-form">
                <div class="md-form">
                <label data-error="wrong" data-success="right">New Password</label>
                <input type="text" name="npass" class="form-control validate">
                <p></p>
              </div>
            </div>          
            <div class="text-center mb-3">
            <button type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="cpass" value="<?php echo $_SESSION['id']; ?>">Change Password</button>
          </div>                 
        </div>
      </div>
    </div>
  </div> 
  </form> -->
  <!-- end of change pass modal -->
        
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Teller Dashboard</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="../assets/favicon.ico" />   
    </head>
    <style>
      body
      {
        background-image: url(../img/3.jpg);
        background-position: center;
        background-repeat: cover;   
      } 
    </style>
    <body id="page-top">
    <!-- Page Content-->  
<form method="POST"> 
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <h3 style="color:white;">Online Bank</h3>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav  ml-auto">
        <a class="nav-item nav-link js-scroll-trigger" name="" aria-current="page" href="#page-top"> <i class="fa fa-home">&nbsp;</i> Home</a>
        <input type="submit" class="btn text-white" name="logout" value="Logout">
      </div>
    </div>
  </div>
</nav>
</form>
<p></p>
<?php
   if($_SESSION['user_status'] == 1):
?> 
<div class="container">
  <div class="row">   
    <div class="col-md-4">
      <div class="card mx-auto bg-dark text-white" style="width: 20rem;">
        <img class="card-img-top mx-auto" src="../img/1.jpg"  style="width:100%;" alt="Login icon">
        <div class="card-body"> 
          <h5 class="card-title">Profile Info</h5>
          <p class="card-text"><i class="fa fa-user">&nbsp;</i><?php echo $_SESSION['user_type']; ?></p>    
          <p class="card-text">Date : <?php echo date("Y-d-m");?></p>
          <a href="Edit_profile" class="btn btn-warning text-white"> <i class="fa fa-edit">&nbsp;</i> Edit Profile</a>
          <p></p>
          <a href="#" data-toggle="modal" data-target="#addemployee" class="btn btn-warning text-white"> <i class="fa fa-plus">&nbsp;</i> Add Admin/Teller</a>
        </div>
      </div>
    </div>
    <?php endif; ?>
    

</div>
</div>
</div> 
</div>   
<!-- Card -->
<p></p>
<div class="container">
<div class="row">
<div class="col-md-4 ">
<div class="card text-center">
      <div class="card-body bg-dark text-white">
        <h5 class="card-title">Deposit</h5>
        <p class="card-text">Here you can Deposit.</p>
        <a href="#" data-toggle="modal" data-target="#deposit" class="btn btn-warning text-white"><i class="fa fa-bank">&nbsp;</i>Deposit</a>
      </div>
    </div>
</div>
   
        <!-- Deposit Modal -->
        <div class="modal fade" id="deposit">
    <form method="POST">
    <?php 
    if (isset($_POST['depo'])) 
    {
      $Deposit = new TransCtr();
      $Deposit->storeDeposit(
        $_POST['users_fk'],
        $_POST['accnum'],
        $_POST['accname'],
        $_POST['amount'],
        $_POST['deposit'],
        $_POST['trans_category'],
        $_POST['id_check']
      );
    }
    ?>
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header text-center">
            <h3 class="modal-title w100 dark-grey-text font-weight-bold">Deposit</h3> 
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>          
          </div>
             <div class="modal-body mx-4">
              <div class="md-form">
              <label data-error="wrong" data-success="right">Account Number</label>
                <input type="text" name="accnum" class="form-control validate" placeholder="004672981745">              
              </div>
              <div class="md-form">
              <label data-error="wrong" data-success="right">Account Name</label>
                <input type="text" name="accname" class="form-control validate" placeholder="Allen">
                <input type="text" name="deposit" class="form-control validate" value="deposit" hidden>              
              </div>
              <div class="md-form">
                <label for="type_of_deposit" class="col-form-label">Type of Deposit</label>
                <div class="">
                    <select class="form-select form-control validate" style="width: 100%;" onchange="hideId()" id="trans_categoryt" name="trans_category" aria-label="type_of_deposit">
                        <option value="" selected>Type of Deposit</option>
                        <option value="cash">Cash</option>
                        <option value="check">Check</option>
                    </select>
                </div>
            </div>
            <div class="row mb-4" id="idCheck">
                <label for="deposit" class="col-md-3 col-form-label">Id Check</label>
                <div class="col-md-9">
                    <input type="number" name="id_check" class="form-control" placeholder="Id Check">
                </div>
            </div>
                <div class="md-form">
                <label data-error="wrong" data-success="right">Amount</label>
                <input type="text" name="amount" class="form-control validate" placeholder="0000.00">
                <input type="text" name="users_fk" value="<?php echo $_SESSION['users_fk'];
                ?>" hidden>
                <p></p>
            </div>
            <div class="text-center mb-3">
            <button type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="depo">Deposit</button>
          </div>                 
        </div>
      </div>  
    </div>
  </div>
</form>
  <!-- End Deposit Modal -->

<div class="col-md-4 ">
<div class="card text-center">
      <div class="card-body bg-dark text-white">
        <h5 class="card-title">Withdraw</h5>
        <p class="card-text">Here you can Withdraw</p>
        <a href="#" data-toggle="modal" data-target="#withdraw" class="btn btn-warning text-white"><i class="fa fa-arrow-down">&nbsp;</i>Withdraw</a>
      </div>
    </div>
</div>
  <!-- Withdraw Modal -->
  <div class="modal fade" id="withdraw">
    <form method="POST">
    <?php
    if(isset($_POST['with']))
    {
      $withdraw = new TransCtr();
      $withdraw->storeWithdraw(
      $_POST['users_fk'],
      $_POST['accnum'],
      $_POST['processname'],
      $_POST['amount'],
      $_POST['withdraw'],
      $_POST['trans_category'],
      $_POST['id_check'] ,
      $_POST['trans_status']
    );}
    ?>
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header text-center">
            <h3 class="modal-title w100 dark-grey-text font-weight-bold">Withdraw</h3>   
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>        
          </div>
             <div class="modal-body mx-4">
             <div class="md-form">
              <div class="md-form">
              
                <input type="number" name="id_check" class="form-control" placeholder="Id Check"hidden>  
                <input type="text" name="withdraw" class="form-control validate" value="withdraw" hidden>
                <input type="text" name="trans_status" class="form-control validate" value="pending" hidden> 
                <input type="text" name="trans_category" class="form-control validate" value="cash" hidden>
                <input type="text" name="processname" class="form-control validate" value="<?php echo $_SESSION['first_name']; ?>" hidden>
              <label data-error="wrong" data-success="right">Account Number</label>
              <input type="text" name="accnum" class="form-control validate" placeholder="0000000000">               
              </div>

                <div class="md-form">
                <label data-error="wrong" data-success="right">Amount</label>
                <input type="text" name="amount" class="form-control validate" placeholder="0000.00">
                <input type="text" name="users_fk" value="<?php echo $_SESSION['users_fk'];
                ?>" hidden>
                <p></p>
            </div>          
            <div class="text-center mb-3">
            <button type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="with">Withdraw</button>

          </div>                 
        </div>
      </div>
    </div>
  </div> </div>
  </form>
  <!-- End Withdraw Modal -->
<div class="col-md-4 ">
<div class="card text-center">
      <div class="card-body bg-dark text-white">
        <h5 class="card-title">Add Employee</h5>
        <p class="card-text">Here you can Add Employee.</p>
        <a href="#" data-toggle="modal" data-target="#trans" class="btn btn-warning text-white"><i class="fa fa-money">&nbsp;</i> Transfer</a>
      </div>
    </div>
</div>
</div>
</div> 
 <!-- Add Employee Modal -->
<div class="modal fade" id="trans">
  <form method="POST">
  <?php
  if(isset($_POST['transfer'])) 
  {
  $transfer = new TransCtr();
  $transfer->storeTransfer(
  $_POST['users_fk'],
  $_POST['accnum'],
  $_POST['accname'],
  $_POST['amount'],
  $_POST['transfer'], 
  $_POST['trans_category'],
  $_POST['id_check'],
  $_POST['trans_status'] );
  }
  ?>
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header text-center">
            <h3 class="modal-title w100 dark-grey-text font-weight-bold">Transfer</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
            </button>           
          </div>
             <div class="modal-body mx-4">
             <div class="md-form">
              <label data-error="wrong" data-success="right">Account Name</label>
                <input type="text" name="accname" class="form-control validate" placeholder="Allen">
                <input type="text" name="transfer" class="form-control validate" value="Transfer" hidden>  
                <input type="text" name="trans_category" class="form-control validate" value="cash" hidden>
                <input type="text" name="trans_status" class="form-control validate" value="pending" hidden>
                <input type="text" name="users_fk" value="<?php echo $_SESSION['users_fk'];
                ?>" hidden>   
                <input type="number" name="id_check" class="form-control" placeholder="Id Check"hidden>        
              </div>
              <div class="md-form">
                <label data-error="wrong" data-success="right">Account Number</label>
                <input type="text" name="accnum" class="form-control validate" placeholder="004672981745">              
              </div>
                <div class="md-form">
                <label data-error="wrong" data-success="right">Amount</label>
                <input type="text" name="amount" class="form-control validate" placeholder="0000.00">
                <input type="text" name="users_fk" value="<?php echo $_SESSION['users_fk'];
                ?>" hidden>
                <p></p>
            </div>
         <div class="text-center mb-3">
            <input type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="transfer" value="Transfer">
          </div>                 
        </div>
      </div>
    </div>
  </div> 
  </form>
  <!-- end Add Employee Modal -->
  
        <!-- Bootstrap core JS-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/scripts.js"></script>
        <script>
    $(document).ready(function() {
        $('#example').DataTable();
    });

    $('#idCheck').hide();

    function hideId() {
        var value = $('#type_of_deposit option:selected').val();
        if (value == 'check') {
            $('#idCheck').show();
        } else {
            $('#idCheck').hide();
        }

    }
</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</body>
</html>
