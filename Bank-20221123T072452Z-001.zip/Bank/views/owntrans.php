<?php
include '../views/layout.php';
?>
<?php
if( $_SESSION['user_type'] == 1) : 
?>
<br>
<center>
<div class="col-md-20">
  <div class="jumbotron bg-dark" style="width:95%;height:100%;">
    <table class="table table-striped table-dark">
      <thead>
       <tr>
        <th class="text-warning">Transaction Number</th>
        <th class="text-warning">Account Number</th>
        <th class="text-warning">Account Name</th>
        <th class="text-warning">Teller Number</th>
        <th class="text-warning">Transaction Type</th>
        <th class="text-warning">Transaction Categories</th>
        <th class="text-warning">Transaction Amount</th>
        <th class="text-warning">Date of transaction</th>
       </tr>
      </thead>
      <tbody>
       <?php 
        $acc_num = $_SESSION['account_num'];
        $sTrans = new TransView();
        $sTrans->showOwnTrans('transaction', 'acc_num = ?' , $acc_num);
        ?>
      </tbody>
    </table>
                  
    </div>
  </div>
  <?php endif; ?>
  <?php
if( $_SESSION['user_type'] == 2) : 
?>
<br>
<center>
<div class="col-md-20">
  <div class="jumbotron bg-dark" style="width:95%;height:100%;">
    <table class="table table-striped table-dark">
      <thead>
       <tr>
        <th class="text-warning">Transaction Number</th>
        <th class="text-warning">Account Number</th>
        <th class="text-warning">Account Name</th>
        <th class="text-warning">Teller Name</th>
        <th class="text-warning">Transaction Type</th>
        <th class="text-warning">Transaction Categories</th>
        <th class="text-warning">Transaction Amount</th>
        <th class="text-warning">Date of transaction</th>
       </tr>
      </thead>
      <tbody>
       <?php 
        $users_fk = $_SESSION['users_fk'];
        $sTrans = new TransView();
        $sTrans->getTrans('transaction', 'users_fk = ? ' , $users_fk);
        ?>
      </tbody>
    </table>
                  
    </div>
  </div>
  <?php endif; ?>