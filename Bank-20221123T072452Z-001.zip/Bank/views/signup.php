<?php

include '../views/layout2.php';
?>
   <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   <link href="../css/Welcome.css" rel="stylesheet" />
   <style>
      body
      {
        background:rgba(0,0,0,0.7)url(../img/signin.jpg);
        background-position: center;
        background-repeat: cover; 
        background-blend-mode: darken;
          
      } 
    </style>
<div>
 <div >
  <form method="POST">
      <br><br><br>
      <div class="card mx-auto" style="width: 30rem;">
      <p></p>
      <?php   
if(isset($_POST['signin'])) {
  $validate = new Validation();
  $validation = $validate->check($_POST, array(
      'email' => array(
          'required' => true,
          'youremail' => 'email',

      ),
      'pwd' => array(
          'required' => true,
          'min' => 8
      ),
  ));
  if ($validation->passed()) {
  $login = new AccountCtr();
  echo $login->signin(
    $_POST['email'],
    Hash::encryptPassword($_POST['pwd']));
}else {
  echo "<div class='text-danger' onclick='error_toast()'><ul> ";

  foreach ($validate->errors() as $error) {
    echo "<li class='text-danger'>" . ucfirst($error) . "</li>";
  }
  echo " </ul></div>";
}
echo "<br>";

Validation::flash("Successful");}
      ?>
      <img src="../img/profile.png" class="mx-auto" style="width:50%; height:70%;" alt="Login icon">
        <div class="card-body">
          <h5 class="card-title"></h5>
        <div class="mb-3">
        <label for="email" class="form-label">Email</label> 
          <label for="email" class="col-md-2 col-form-label text-md-right">
         </label>
        <input id="email" type="email" class="form-control" name="email">
         
        <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input id="pwd" type="password" class="form-control" name="pwd">
          </div>
          <button type="submit" class="btn btn-dark" name="signin" id="signin"> <i class="fa fa-lock">&nbsp;</i> SignIn
    </button>

          &nbsp;<span> <a href="register.php">Register</a> </span>
      </form>    
      
      </div>
      <footer class="py-100">
                <p></p>
            <div class="container"><p class="m-0 text-center text-dark">Copyright &copy;2021</p></div>
             </footer>
      </div></div>
      </body>
      </html

