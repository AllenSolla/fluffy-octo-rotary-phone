<?php
include '../includes/class-autoloader.inc.php';
session_start();
if(!isset($_SESSION['email']) && !isset($_SESSION['pwd'])) 
{
  header("Location: index.php");
}
if(isset($_POST['logout'])) 
  Account::logout();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="../assets/favicon.ico" />  
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/layout.css" rel="stylesheet" />
    </head>
    <style>
      body
      {
        background:rgba(0,0,0,0.7)url(../img/3.jpg);
        background-position: center;
        background-repeat: cover; 
        background-blend-mode: darken;
          
      } 
    </style>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-dark" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-dark text-warning">Online Banking</div>
                <div class="list-group list-group-flush">
                <img class="card-img-top mx-auto" src="../img/login.jpg"  style="width:100%;" alt="Login icon">
                <br>
                <?php if( $_SESSION['user_type'] == 1 || $_SESSION['user_type'] == 2)  : ?>
                <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="owntrans.php"><center>Transaction History</center></a>
                <?php endif ;?>
                <?php
                if( $_SESSION['user_type'] == 2) : 
                ?>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="Deposit.php"><center>Deposit</center></a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="Withdraw.php"><center>Withdraw</center></a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="Acceptcus.php"><center>Customer Reqest Form</center></a>
                <?php endif ?>

                <?php
                if( $_SESSION['user_type'] == 1) : 
                ?>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="Transfer.php"><center>Transfer</center></a>
                <?php endif ?>
                
                <?php
                if( $_SESSION['user_type'] == 3 || $_SESSION['user_type'] == 4) : 
                ?>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="Alltransaction.php"><center> All Transaction History</center></a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="Addemployee.php"><center>Add Teller/Manager</center></a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="ListEmplo.php"><center>List of Employee</center></a>
                <?php endif ?>
                <a class="list-group-item list-group-item-action list-group-item-light p-3 text-dark" href="changepass.php"><center>Change Password</center></a>
                    
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <form method="POST">
                <nav class="navbar navbar-expand-lg navbar-light bg-dark border-bottom">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <a class="nav-item nav-link js-scroll-trigger text-warning" name="" aria-current="page" href="Dashboard.php"><i class="fa fa-home">&nbsp;</i>Home</a></li>
                                <button type="submit" class="btn text-warning" name="logout"> Logout </button>
                            </ul>
                        </div>
                    </div>
                </nav>
    </form>
                <!-- Page content-->
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/layout.js"></script>
    </body>
</html>
