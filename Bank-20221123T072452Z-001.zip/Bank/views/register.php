<?php
include '../views/layout2.php';
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="../css/signup.css?<?php echo time(); ?>" rel="stylesheet" />
    <link rel="icon" type="image/x-icon" href="../assets/favicon.ico" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</head>
<form method="POST">

<div class="container" >
<div class="card mx-auto bg-dark" style="width: 80vw;">

<div class="row p-5">
<center> <h2 class="text-white">Register Form</h2></center>
<?php
if(isset($_POST['register'])){
  $validate = new Validation();
$validation = $validate->check($_POST, array(
    'email' => array(
        'required' => true,
        'youremail' => 'email',
        'unique' => 'unique',
    ),
    'pwd' => array(
        'required' => true,
        'min' => 8
    ),
    'firstname' => array(
        'required' => true
    ),
    'middlename' => array(
        'required' => true
    ),
    'lastname' => array(
        'required' => true
    ),
    'exname' => array(
        'required' => true
    ),
    'housenum' => array(
        'required' => true
    ),
    'sname' => array(
        'required' => true
    ),
    'brgy' => array(
        'required' => true
    ),
    'city' => array(
        'required' => true
    ),
    'country' => array(
        'required' => true
    ),
    'zipcode' => array(
        'required' => true
    ),
    'birthday' => array(
        'required' => true
    ),
    'cstatus' => array(
        'required' => true
    ),
    'gender' => array(
        'required' => true
    ),
    'contact_num' => array(
        'required' => true
    ),
    'Mother_s' => array(
      'required' => true
    ),
    'Mother_m' => array(
      'required' => true
    ),
    'Mother_f' => array(
    'required' => true
    ),
    'usertype' => array(
        'required' => true
    )

));
if ($validation->passed()) {
$createCus = new AccountCtr();
echo $createCus->createAccount(
$_POST['lastname'],
$_POST['middlename'],
$_POST['firstname'],
$_POST['exname'],
$_POST['email'],
Hash::encryptPassword($_POST['pwd']),
$_POST['gender'],
$_POST['cstatus'],
$_POST['housenum'],
$_POST['sname'],
$_POST['brgy'],
$_POST['city'],
$_POST['zipcode'],
$_POST['country'],
$_POST['usertype'],
$_POST['softdelete'],
$_POST['status'],
$_POST['teller_id'],
$_POST['birthday'],
$_POST['Mother_s'],
$_POST['Mother_m'],
$_POST['Mother_f'],
$_POST['contact_num'],
$_POST['account_num'],
$_POST['bbranch'],
$_POST['bal']
);
}else {
  echo "<div class='text-danger' onclick='error_toast()'><ul> ";

  foreach ($validate->errors() as $error) {
    echo "<li>" . ucfirst($error) . "</li>";
  }
  echo " </ul></div>";
}
echo "<br>";

Validation::flash("Successful");}
?>
      <hr class="bg-white"><p></p>
      <div  class="py-3 col-md-4">
    <label  class="form-label text-white">Last name</label>
    <input type="hidden" id="usertype" name="usertype" value="1">
    <input type="hidden" id="softdelete" name="softdelete" value="0">
    <input type="hidden" id="status" name="status" value="0">
    <input type="hidden" id="teller_id" name="teller_id" value="">
    <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name" value="<?php if(!empty($_POST['lastname'])) echo $_POST['lastname'] ; ?>">
      </div>
  
  <div  class="py-3 col-md-4">
    <label for="validationServer02" class="form-label text-white">Middle name</label>
    <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Middle Name" value="<?php if(!empty($_POST['middlename'])) echo $_POST['middlename'] ; ?>" >
  </div>
  
  <div  class="py-3 col-md-4">
    <label for="validationServerUsername" class="form-label text-white">First name</label>
    <div class="input-group has-validation">
      <input type="text" class="form-control" id="firstname" name="firstname" value="<?php if(!empty($_POST['firstname'])) echo $_POST['firstname'] ; ?>" placeholder="First Name" >
    </div>
  </div>
  
  <div class="py-3 col-md-2">
    <label for="validationServer03" class="form-label text-white">ex.name</label>
    <input type="text" class="form-control" id="exname" name="exname" placeholder="jr." value="<?php if(!empty($_POST['exname'])) echo $_POST['exname'] ; ?>">
  </div>
  
  <div  class="py-3 col-md-4">
    <label for="validationServer03" class="form-label text-white">Email</label>
    <input type="email" class="form-control" id="email" name="email" value="<?php if(!empty($_POST['email'])) echo $_POST['email'] ; ?>" placeholder="Enter your Email" >
  </div>
  
  <div  class="py-3 col-md-4">
    <label for="validationServer05" class="form-label text-white">Password</label>
    <input type="password" class="form-control" id="pwd" name="pwd" value="<?php if(!empty($_POST['pwd'])) echo $_POST['pwd'] ; ?>" placeholder="must be 8-16 characters" >
  </div>
  
  <div  class="py-3 col-md-2">
    <label for="validationServer05" class="form-label text-white">Gender</label>
    <input type="text" class="form-control" id="gender" name="gender" value="<?php if(!empty($_POST['gender'])) echo $_POST['gender'] ; ?>" placeholder="Gender" >
  </div>
  
  <div  class="py-3 col-md-2">
    <label for="validationServer05" class="form-label text-white">Civil Status</label>
    <input type="text" class="form-control" id="cstatus" name="cstatus" value="<?php if(!empty($_POST['cstatus'])) echo $_POST['cstatus'] ; ?>" placeholder="Enter your Civil Status" >
  </div>
  
  <div  class="py-3 col-md-3">
    <label for="validationServer05" class="form-label text-white">House Number</label>
    <input type="text" class="form-control" id="housenum" name="housenum" value="<?php if(!empty($_POST['housenum'])) echo $_POST['housenum'] ; ?>" placeholder="House Number" >
  </div>
  
  <div  class="py-3 col-md-3">
    <label for="validationServer05" class="form-label text-white">Street Name</label>
    <input type="text" class="form-control" id="sname" name="sname" value="<?php if(!empty($_POST['sname'])) echo $_POST['sname'] ; ?>" placeholder="Enter your Street Name" >
  </div>
  
  <div  class="py-3 col-md-4">
    <label for="validationServer05" class="form-label text-white">Baranggay</label>
    <input type="text" class="form-control" id="brgy" name="brgy" value="<?php if(!empty($_POST['brgy'])) echo $_POST['brgy'] ; ?>" placeholder="Enter your Brgy" >
  </div>
  
  <div  class="py-3 col-md-4">
    <label for="validationServer05" class="form-label text-white">City/Municipality</label>
    <input type="text" class="form-control" id="city" name="city" value="<?php if(!empty($_POST['city'])) echo $_POST['city'] ; ?>" placeholder="Enter your City/Municipality" >
  </div>

  <div  class="py-3 col-md-2">
    <label for="validationServer05" class="form-label text-white">Zip Code</label>
    <input type="text" class="form-control" id="zipcode" name="zipcode" value="<?php if(!empty($_POST['zipcode'])) echo $_POST['zipcode'] ; ?>" placeholder="Zip Code" >
  </div>

  <div  class="py-3 col-md-3">
    <label for="validationServer05" class="form-label text-white">Country</label>
    <input type="text" class="form-control" id="country" name="country" value="<?php if(!empty($_POST['lastname'])) echo $_POST['lastname'] ; ?>" placeholder="Enter your Country" >
  </div>

  <div  class="py-3 col-md-3">
    <label for="validationServer05" class="form-label text-white">Birthday</label>
    <input type="date" class="form-control" id="birthday" id="birthday" name="birthday" value="<?php if(!empty($_POST['birthday'])) echo $_POST['birthday'] ; ?>" placeholder="Enter your Birthdate" >
  </div>

  <div class="py-3 col-md-6">
    <label for="validationServer05" class="form-label text-white">Contact Number</label>
    <input type="" class="form-control" id="contact_num" name="contact_num" value="<?php if(!empty($_POST['contact_num'])) echo $_POST['contact_num'] ; ?>" placeholder="Mobile/telephone number" >
  </div>

  <div  class="py-3 col-md-6">
    <label for="validationServer05" class="form-label text-white">Mother SurName(Maiden)</label>
    <input type="text" class="form-control" id="Mother_s" name="Mother_s" value="<?php if(!empty($_POST['Mother_s'])) echo $_POST['Mother_s'] ; ?>" placeholder="Mother SurName" >
  </div>

  <div div class="py-3 col-md-6">
    <label for="validationServer05" class="form-label text-white">Mother Middle Name</label>
    <input type="text" class="form-control" id="Mother_m" name="Mother_m" value="<?php if(!empty($_POST['Mother_m'])) echo $_POST['Mother_m'] ; ?>" placeholder="Mother Middle Name" >
  </div>

  <div div class="py-3 col-md-6">
    <label for="validationServer05" class="form-label text-white">Mother First Name</label>
    <input type="text" class="form-control" id="Mother_f" name="Mother_f" value="<?php if(!empty($_POST['Mother_f'])) echo $_POST['Mother_f'] ; ?>" placeholder="Mother First Name" >
  </div>
  <?php
    $test = new AccountCtr();
 ?>
    <input type="text" id="account_num" name="account_num" value="<?php echo $test->createincAccnum();  ?>" hidden>
  
    <div div class="py-3 col-md-4">
    <label for="validationServer05" class="form-label text-white">Bank Branch</label>
    <input type="text" class="form-control" id="bbranch" name="bbranch" value="<?php if(!empty($_POST['bbranch'])) echo $_POST['bbranch'] ; ?>" placeholder="Enter Bank branch" >
    <input type="text" id="bal" name="bal" value="0.00"  hidden>
  </div>

  <div class="col-12">
  <button type="submit" class="btn btn-primary text-white" name="register">Register</button>

    &nbsp;<a href="index.php" class="btn btn-white text-white">Back</a>
  </div>
</div>  
</div>
</div>
</form>