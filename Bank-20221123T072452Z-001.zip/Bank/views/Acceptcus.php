<?php
include '../views/layout.php';;
?>
<br>
<center>
<div class="col-md-15">
  <div class="jumbotron bg-dark" style="width:98%;height:100%;">
  <?php
  if(isset($_POST['accept']))
  {
  $test = new AccountCtr();
  $test->accept(
  $_POST['status'],
  $_POST['teller_id'],
  $_POST['accept'],
  $_POST['bal']
  );
  print_r($_POST);
  } else if (isset($_POST['denied'])) {
    $test = new AccountCtr();
    $test->denied(
    $_POST['status'],
    $_SESSION['teller_id'],
    $_POST['denied']);
  }
  ?>
    <table class="table table-striped table-dark">
      <thead>
       <tr>
        <th class="text-warning">Last Name</th>
        <th class="text-warning">Middle Name</th>
        <th class="text-warning">First Name</th>
        <th class="text-warning">ex.Name</th>
        <th class="text-warning">House Number</th>
        <th class="text-warning">Street</th>
        <th class="text-warning">Baranggay</th>
        <th class="text-warning">Municipality</th>
        <th class="text-warning">Balance</th>
        <th class="text-warning">Action</th>
       </tr>
      </thead>
      <tbody>
       <?php 
        $users_fk = $_SESSION['users_fk'];
        $sTrans = new AccountView();
        $sTrans->showAllCus("");
        ?>
      </tbody>
    </table>
                  
    </div>
  </div>
</center>
  <br>
<center>
<div class="container">
<div class="col-md-15">
  <div class="jumbotron bg-dark" style="width:98%;height:100%;">
    <table class="table table-striped table-dark">
      <thead>
       <tr>
        <th class="text-warning">Last Name</th>
        <th class="text-warning">Middle Name</th>
        <th class="text-warning">First Name</th>
        <th class="text-warning">ex.Name</th>
        <th class="text-warning">House Number</th>
        <th class="text-warning">Street</th>
        <th class="text-warning">Baranggay</th>
        <th class="text-warning">Municipality</th>
       </tr>
      </thead>
      <tbody>
       <?php 
        $users_fk = $_SESSION['users_fk'];
        $sTrans = new AccountView();
        $sTrans->accept("");
        ?>
      </tbody>
    </table>
    </div>             
    </div>
  </div></center>