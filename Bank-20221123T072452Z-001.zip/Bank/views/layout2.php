<?php
include '../includes/class-autoloader.inc.php';
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['pwd'])) 
{
  if (isset($_SESSION['status']) == 1 ) 
  {
    header("Location: Dashboard.php");
  } 
  
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Online Bank</title>
        <link rel="icon" type="image/x-icon" href="../assets/favicon.ico" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" integrity="sha384-wESLQ85D6gbsF459vf1CiZ2+rr+CsxRY0RpiF1tLlQpDnAgg6rwdsUF1+Ics2bni" crossorigin="anonymous">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/Welcome.css?<?php echo time();?>" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger text-warning" href="#page-top">Online Bank</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger text-warning" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger text-warning" href="signup.php">Get Started</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger text-warning" href="#about">About</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger text-warning" href="#services">Services</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger text-warning" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>

