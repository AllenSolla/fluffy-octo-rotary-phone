<?php

include '../views/layout.php';
?>

   <link href="../css/form.css" rel="stylesheet">
<div class="form">
 <div class="container-fluid">
  <br><br><br><br><br>
  <h1>Deposit</h1>
    <form method="POST">
    <?php 
    if (isset($_POST['depo'])) 
    {
      $Deposit = new TransCtr();
     echo $Deposit->storeDeposit(
        $_POST['users_fk'],
        $_POST['accnum'],
        $_POST['firstname'],
        $_POST['middlename'],
        $_POST['lastname'],
        $_POST['amount'],
        $_POST['deposit'],
        $_POST['trans_category'],
        $_POST['id_check']
      );
    }
    Validation::flash("Successful Message");
    ?>
<div class="mb-3">
    <input type="text" name="deposit" class="form-control validate" value="deposit" hidden>
    <input type="text" name="users_fk" value="<?php echo $_SESSION['users_id'];?>" hidden>
    <label for="exampleInputEmail1"  class="form-label">Account Number</label>
    <input type="text" class="form-control" name="accnum" id="accnum">
</div>

<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">first Name</label>
        <input type="text" class="form-control" name="firstname" id="acc_name" require>
</div>
<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Middle Name</label>
        <input type="text" class="form-control" name="middlename" id="acc_name" require>
</div>
<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Last Name</label>
        <input type="text" class="form-control" name="lastname" id="acc_name" require>
</div>

<div class="mb-3">
    <label for="type_of_deposit" class="col-form-label">Type of Deposit</label>
    <div class="">
        <select class="form-select form-control validate" style="width: 100%;" onchange="hideId()" id="type_of_deposit" name="trans_category" aria-label="type_of_deposit">
            <option value="" selected>Type of Deposit</option>
            <option value='cash'>Cash</option>
            <option value='check'>Check</option>
        </select>
    </div>
</div>
<div class="row mb-4" id="idCheck">
    <label for="deposit" class="col-md-3 col-form-label">Id Check</label>
    <div class="col-md-9">
        <input type="number" name="id_check" class="form-control" placeholder="Id Check">
    </div>
</div>
<div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Amount</label>
    <input type="text" class="form-control" name="amount" id="amount" require>
</div>
<div class="text-center mb-3">
    <button type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="depo">Deposit</button>
</form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="../js/scripts.js"></script>
    <script>

$('#idCheck').hide();
    function hideId() {
        var value = $('#type_of_deposit option:selected').val();
        if (value == 'check') {
            $('#idCheck').show();
        } else {
            $('#idCheck').hide();
        }

    }
    </script>
    