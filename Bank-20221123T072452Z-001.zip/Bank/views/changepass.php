<?php

include '../views/layout.php';
?>
<link href="../css/form.css" rel="stylesheet">
<div class="form">
 <div class="container-fluid">
  <h1 >Change Password</h1>
    <form method="POST">
    <?php 
   if(isset($_POST['cpass'])) {
   $cPass = new AccountCtr();
   echo $cPass->createpass( Hash::encryptPassword($_POST['npass']), $_SESSION['users_id']);
   Validation::flash("Successful Message"); 
   }
    ?>
   <div class="mb-3">
        <center>
        <label for="exampleInputEmail1"  class="form-label">Enter New Password!</label></center>
        <input type="password" name="npass" class="form-control validate">
   </div>
    <div class="text-center mb-3">
        <button type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="cpass">Change</button>
</form>
            </div>
        </div>
    </div>
</div>

    