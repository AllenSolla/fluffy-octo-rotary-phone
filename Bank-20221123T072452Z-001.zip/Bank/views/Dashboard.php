<?php
include '../views/layout.php';
?>
<?php
if( $_SESSION['user_type'] == 1) : 
?>
<br><br><br><br><br><br>
<div class="card text-center">
  <div class="card-header">
    
  </div>
  <div class="card-body">
    <h5 class="card-title">Account Number :</h5>
    <h3 class="card-text"><?php echo $_SESSION['account_num']; ?></h3>
    <h5 class="card-title">Balance : </h5>

    <h3 class="card-text"><?php echo $_SESSION['balance'];?></h3>
    </div>
    <div class="card-header"></div>
</div>
<?php endif?>
<?php
if( $_SESSION['user_type'] == 2) : 
?>
<br><br><br><br><br><br>
<div class="card text-center">
  <div class="card-header">
    
  </div>
  <div class="card-body">
    <h5 class="card-title">Teller Number :</h5>
    <h3 class="card-text"><?php echo $_SESSION['users_id']; ?></h3>
    <h5 class="card-title">Teller Name : </h5>

    <h3 class="card-text"><?php echo $_SESSION['first_name'];?></h3>
    </div>
    <div class="card-header"></div>
</div>
<?php endif?>