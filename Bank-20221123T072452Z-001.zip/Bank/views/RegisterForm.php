<?php
include '../includes/class-autoloader.inc.php';
?>
<DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="../css/Register.css" rel="stylesheet" />
</head>
<body>
  <div class="container">
    <div class="title"> Registration Form</div>
    <?php
if(isset($_POST['register'])){
$createCus = new AccountCtr();
$createCus->createAccount(
$_POST['lastname'],
$_POST['middlename'],
$_POST['firstname'],
$_POST['exname'],
$_POST['email'],
$_POST['pwd'],
$_POST['gender'],
$_POST['cstatus'],
$_POST['housenum'],
$_POST['sname'],
$_POST['brgy'],
$_POST['city'],
$_POST['zipcode'],
$_POST['country'],
$_POST['usertype'],
$_POST['softdelete'],
$_POST['status'],
$_POST['birthday'],
$_POST['Mother_s'],
$_POST['Mother_m'],
$_POST['Mother_f'],
$_POST['contact_num'],
$_POST['account_num'],
$_POST['bbranch'],
$_POST['bal']
);
}
?>
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Last Name</span>
            <input type="hidden" id="usertype" name="usertype" value="0">
            <input type="hidden" id="softdelete" name="softdelete" value="0">
            <input type="hidden" id="status" name="status" value="0">
            <input type="text" id="lastname" name="lastname" placeholder="Enter your Last Name" required>
          
          
          <div class="input-box">
            <span class="details">Middle Name</span>
            <input type="text" id="middlename" name="middlename" placeholder="Enter your Middle Name" required>
          
          
          <div class="input-box">
            <span class="details">First Name</span>
            <input type="text" id="firstname" name="firstname" placeholder="Enter your First Name" required>
          
          
          <div class="input-box">
            <span class="details">ex.Name</span>
            <input type="text" id="exname" name="exname" placeholder="jr." >
          
          
            <div class="input-box">
            <span class="details">Email</span>
            <input type="email" id="email" name="email" placeholder="Enter your Email" required>
          
          
          <div class="input-box">
            <span class="details">Password</span>
            <input type="text" id="pwd" name="pwd" value="000000"readonly>
          
          
          <div class="input-box">
            <span class="details">Gender</span>
            <input type="text" id="gender" name="gender" placeholder="Enter your Gender" required>
          
          
          <div class="input-box">
            <span class="details">Civil Status</span>
            <input type="text" id="cstatus" name="cstatus" placeholder="Enter your Civil Status" required>
          
          
          <div class="input-box">
            <span class="details">House Number</span>
            <input type="text" id="housenum" name="housenum" placeholder="Enter your House Number" required>
          
          
          <div class="input-box">
            <span class="details">Street Name</span>
            <input type="text" id="sname" name="sname" placeholder="Enter your Street Name" required>
          
          
          <div class="input-box">
            <span class="details">Baranggay</span>
            <input type="text" id="brgy" name="brgy" placeholder="Enter your Brgy" required>
          
          
          <div class="input-box">
            <span class="details">City/Municipality</span>
            <input type="text" id="city" name="city" placeholder="Enter your City/Municipality" required>
          
          
          <div class="input-box">
            <span class="details">Zip Code</span>
            <input type="text" id="zipcode" name="zipcode" placeholder="Enter your Area Code" required>
          
          
          <div class="input-box">
            <span class="details">Country</span>
            <input type="text" id="country" name="country" placeholder="Enter your Country" required>
          
          
          <div class="input-box">
            <span class="details">Birthdate</span>
            <input type="date" id="birthday" name="birthday" placeholder="Enter your Birthdate" required>


            <div class="input-box">
            <span class="details">Contact Number</span>
            <input type="number" id="contact_num" name="contact_num" placeholder="Mobile/telephone number" required>


            <div class="input-box">
            <span class="details">Mother SurName(Maiden)</span>
            <input type="text" id="Mother_s" name="Mother_s" placeholder="Mother SurName" required>
            
            
            <div class="input-box">
            <span class="details">Mother Middle Name</span>
            <input type="text" id="Mother_m" name="Mother_m" placeholder="Mother Middle Name" required>
          
          
          <div class="input-box">
            <span class="details">Mother First Name</span>
            <input type="text" id="Mother_f" name="Mother_f" placeholder="Mother First Name" required>
            <?php
            $test = new AccountCtr();
            ?>
            <input type="text" id="account_num" name="account_num" value="<?php echo $test->createincAccnum();  ?>" hidden>
          
          
          <div class="input-box">
            <span class="details">Bank Branch</span>
            <input type="text" id="bbranch" name="bbranch" placeholder="Enter Bank branch" required>         
          
          
          <div class="input-box">
            <input type="text" id="bal" name="bal" value="0.00"  hidden>
          
          <div>
            <input type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="register" value="Register">
            <a href="index.php"> <input type="button" class="btn bg-dark btn-block text-white z-depth-la" value="Back"> </a>
      </div>   
  </div>
  </form>
</body>
</html>