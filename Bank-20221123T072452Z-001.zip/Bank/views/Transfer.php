<?php

include '../views/layout.php';
?>
   <link href="../css/form.css" rel="stylesheet">
<div class="form">
 <div class="container-fluid">
 <br><br><br>
  <h1 >Transfer Fund</h1>
    <form method="POST">
    <?php 
    if (isset($_POST['transfer'])) 
    {
      $transfer = new TransCtr();
      echo $transfer->storeTransfer(
        
        $_POST['users_fk'],
        $_POST['accnum'],
        $_POST['firstname'],
        $_POST['middlename'],
        $_POST['lastname'],
        $_POST['amount'],
        $_POST['transfer_type']
      );
    }
    Validation::flash("Successful Message");
    ?>
   <div class="mb-3">
        <input type="text" name="transfer_type" class="form-control validate" value="transfer" hidden>
        <input type="text" name="trans_category" class="form-control validate" value="cash" hidden>
        <input type="hidden" name="id_check" class="form-control" placeholder="Id Check">
        <input type="text" name="users_fk" value="<?php echo $_SESSION['users_fk'];?>" hidden>
        <label for="exampleInputEmail1"  class="form-label">Account Number</label>
        <input type="text" class="form-control" name="accnum" id="accnum">
   </div>

   <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">first Name</label>
        <input type="text" class="form-control" name="firstname" id="acc_name" require>
</div>
<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Middle Name</label>
        <input type="text" class="form-control" name="middlename" id="acc_name" require>
</div>
<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Last Name</label>
        <input type="text" class="form-control" name="lastname" id="acc_name" require>
</div>

    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Amount</label>
        <input type="text" class="form-control" name="amount" id="amount" require>
    </div>

    <div class="text-center mb-3">
    <input type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="transfer" value="Transfer">
</form>
            </div>
        </div>
    </div>
</div>

    