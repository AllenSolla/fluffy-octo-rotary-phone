<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>We are processing your account</h1>
    <a href="index.php"> <input type="submit" class="btn bg-dark btn-block text-white z-depth-la" value="Ok"> </a>

</body>
</html>