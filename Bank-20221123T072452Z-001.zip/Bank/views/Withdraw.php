<?php

include '../views/layout.php';
?>
   <link href="../css/form.css" rel="stylesheet">
<div class="form">
 <div class="container-fluid">
  <h1>Withdraw</h1>
    <form method="POST">
    <?php 
    if (isset($_POST['with'])) 
    {
      $Deposit = new TransCtr();
     echo $Deposit->storeWithdraw(
        $_POST['users_fk'],
        $_POST['accnum'],
        $_POST['firstname'],
        $_POST['middlename'],
        $_POST['lastname'],
        $_POST['amount'],
        $_POST['withdraw']
      );
    }
    Validation::flash("Successful Message");
    ?>
<div class="mb-3">
    <input type="text" name="withdraw" class="form-control validate" value="withdraw" hidden>
    <input type="text" name="users_fk" value="<?php echo $_SESSION['users_id'];?>" hidden>
    <label for="exampleInputEmail1"  class="form-label">Account Number</label>
    <input type="text" class="form-control" name="accnum" id="accnum">
</div>

<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">first Name</label>
        <input type="text" class="form-control" name="firstname" id="acc_name" require>
</div>
<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Middle Name</label>
        <input type="text" class="form-control" name="middlename" id="acc_name" require>
</div>
<div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Last Name</label>
        <input type="text" class="form-control" name="lastname" id="acc_name" require>
</div>

<div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Amount</label>
    <input type="text" class="form-control" name="amount" id="amount" require>
</div>
<div class="text-center mb-3">
    <button type="submit" class="btn bg-dark btn-block text-white z-depth-la" name="with">Withdraw</button>
</form>
            </div>
        </div>
    </div>
</div>

    